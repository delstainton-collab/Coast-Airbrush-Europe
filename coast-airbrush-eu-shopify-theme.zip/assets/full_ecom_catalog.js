export const ECOM_CATALOG = [
  {
    "id": "kroma-mirror-chrome-system",
    "brand": "Kroma Edge",
    "category": "Mirror Chrome Systems",
    "name": "Kroma Edge Self-Organizing Mirror Chrome System",
    "sku": "KE-MIRROR-SYS",
    "priceGbp": 260.2,
    "priceEur": 306.12,
    "inStock": false,
    "isPreOrder": true,
    "badge": "BATCH 1 PRE-ORDER",
    "image": "Images/Promo Images/Cleaned Skull Image.jpeg",
    "description": "The world's first self-organizing 2K optical coating that delivers a flawless, non-clouding mirror finish across any industry. Chemically bonds and aligns metallic particles to lock in true mirror reflection over plastics, wood, 3D resin, aluminum, and steel without requiring a gloss black groundcoat. Mix ratio 5:5:2:2 (Binder : Reducer : Hardener : Mirror Seeds).",
    "sizes": [
      "Small Kit (140g / 5 oz)",
      "Medium Kit (420g / 15 oz)",
      "Large Kit (1260g / 45 oz)",
      "Extra Large Kit (2520g / 90 oz)",
      "Ultra Large Kit (10080g / 360 oz)"
    ],
    "packSizes": [
      "Complete 4-Part Kit"
    ],
    "hasOptions": true,
    "hasFullMatrix": false,
    "packPriceMatrix": [
      {
        "packSize": "Small Kit (140g / 5 oz)",
        "stockCode": "KE-MIRROR-140G",
        "coverage": "7–10 sq ft (0.5 m²)",
        "priceGbp": 260.2,
        "priceEur": 306.12,
        "priceRetailGbp": 260.2,
        "priceRetailEur": 306.12,
        "priceRrpIncVat": 312.24,
        "sku": "KE-MIRROR-140G"
      },
      {
        "packSize": "Medium Kit (420g / 15 oz)",
        "stockCode": "KE-MIRROR-420G",
        "coverage": "22–30 sq ft (1.5 m²)",
        "priceGbp": 709.63,
        "priceEur": 834.86,
        "priceRetailGbp": 709.63,
        "priceRetailEur": 834.86,
        "priceRrpIncVat": 851.56,
        "sku": "KE-MIRROR-420G"
      },
      {
        "packSize": "Large Kit (1260g / 45 oz)",
        "stockCode": "KE-MIRROR-1260G",
        "coverage": "68–90 sq ft (4.0 m²)",
        "priceGbp": 1596.67,
        "priceEur": 1878.44,
        "priceRetailGbp": 1596.67,
        "priceRetailEur": 1878.44,
        "priceRrpIncVat": 1916,
        "sku": "KE-MIRROR-1260G"
      },
      {
        "packSize": "Extra Large Kit (2520g / 90 oz)",
        "stockCode": "KE-MIRROR-2520G",
        "coverage": "135–180 sq ft (8.0 m²)",
        "priceGbp": 2874,
        "priceEur": 3381.18,
        "priceRetailGbp": 2874,
        "priceRetailEur": 3381.18,
        "priceRrpIncVat": 3448.8,
        "sku": "KE-MIRROR-2520G"
      },
      {
        "packSize": "Ultra Large Kit (10080g / 360 oz)",
        "stockCode": "KE-MIRROR-10080G",
        "coverage": "500–700 sq ft (32.0 m²)",
        "priceGbp": 10127.04,
        "priceEur": 11914.16,
        "priceRetailGbp": 10127.04,
        "priceRetailEur": 11914.16,
        "priceRrpIncVat": 12152.45,
        "sku": "KE-MIRROR-10080G"
      }
    ],
    "images": [
      "Images/Promo Images/Cleaned Skull Image.jpeg",
      "Images/kromaedge/kroma-helmet-mirror.jpg",
      "Images/kromaedge/kroma-skull-mirror.jpg",
      "Images/kromaedge/kroma-silver-surfer-wave.jpg"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "Perfect Chrome in Minutes: Spray Chrome Mirror Finish with 2K Clear (DIY Method)",
        "creator": "Hype Universal",
        "url": "https://www.youtube.com/watch?v=ag3aDYxdKQ0",
        "embedId": "ag3aDYxdKQ0",
        "duration": "7:15",
        "badge": "Chrome Tutorial"
      },
      {
        "platform": "youtube",
        "title": "Silver Chrome Spray with Topcoat Demonstration",
        "creator": "Eureka Auto",
        "url": "https://www.youtube.com/watch?v=4NAz3k5N6rk",
        "embedId": "4NAz3k5N6rk",
        "duration": "5:40",
        "badge": "Application Guide"
      },
      {
        "platform": "youtube",
        "title": "Armored Komodo ChromaFlair Pigment - Review & Tutorial",
        "creator": "Custom Paint Lab",
        "url": "https://www.youtube.com/watch?v=a5ssSjMgnRE",
        "embedId": "a5ssSjMgnRE",
        "duration": "8:50",
        "badge": "Pigment Review"
      }
    ],
    "summary": "The world's first self-organizing 2K optical mirror coating. Delivers a flawless, true chrome reflection over plastics, wood, 3D resin, aluminium, and steel without requiring a black basecoat or flame treatment.",
    "benefits": [
      "Zero Gray Clouding: Patented microscopic metallic alignment particles lay completely flat to reflect 98%+ visible light like real chrome plating.",
      "No Black Basecoat Required: Bonds chemically and optically to a wide variety of primed or cleared substrates.",
      "Easy 1-Wet-Coat Application: Sprays at 20–25 PSI with standard airbrushes (0.3–0.5mm) or mini spray guns (0.8–1.2mm).",
      "UV Stable & Non-Oxidizing: Resistant to yellowing and peeling when paired with Kroma Dedicated Clear."
    ],
    "howItWorks": [
      "Step 1 - Smooth Base: Ensure substrate is completely smooth and cured (gloss finish).",
      "Step 2 - Apply Kroma Chrome: Spray 1 continuous, wet, uniform coat of mixed Kroma Chrome at 20–25 PSI. Watch the mirror self-organize as carrier flashes.",
      "Step 3 - Lock With Dedicated Clear: After 30 minutes flash, apply Kroma Edge Dedicated Topcoat Clear to seal without dulling."
    ],
    "inTheBox": [
      "Kroma Mirror Chrome Base",
      "Kroma Dedicated Reducer",
      "Kroma Optical Hardener",
      "Kroma Mirror Seeds Alignment Activator",
      "Complete Mixing & Application Guide"
    ]
  },
  {
    "id": "kroma-dedicated-topcoat-clear",
    "brand": "Kroma Edge",
    "category": "Dedicated Clearcoats",
    "name": "Kroma Edge Dedicated Topcoat Clear System",
    "sku": "KE-TOPCOAT-CLR",
    "priceGbp": 62.09,
    "priceEur": 73.05,
    "inStock": false,
    "isPreOrder": true,
    "badge": "BATCH 1 PRE-ORDER",
    "image": "Images/kromaedge/kroma-silver-surfer-front.jpg",
    "description": "Specifically engineered topcoat clear for Kroma Edge Chrome systems with ultra-low turbidity and maximum optical clarity. Formulated to prevent clouding, lifting, or solvent reactivation of the aligned metallic mirror layer. Mix ratio 10:1 (Clear Base : Hardener) + 70-100% Dedicated Thinner.",
    "sizes": [
      "Topcoat Clear 180 SET (1.5 m²)",
      "Topcoat Clear 900 SET (6.0 m²)",
      "Topcoat Clear 3600 SET (24.0 m²)"
    ],
    "packSizes": [
      "Base + Hardener + Thinner Set"
    ],
    "hasOptions": true,
    "hasFullMatrix": false,
    "packPriceMatrix": [
      {
        "packSize": "Topcoat Clear 180 SET (1.5 m²)",
        "priceGbp": 62.09,
        "priceEur": 73.05,
        "priceRetailGbp": 62.09,
        "priceRetailEur": 73.05,
        "priceRrpIncVat": 74.51
      },
      {
        "packSize": "Topcoat Clear 900 SET (6.0 m²)",
        "priceGbp": 274.98,
        "priceEur": 323.51,
        "priceRetailGbp": 274.98,
        "priceRetailEur": 323.51,
        "priceRrpIncVat": 329.98
      },
      {
        "packSize": "Topcoat Clear 3600 SET (24.0 m²)",
        "priceGbp": 995,
        "priceEur": 1170.59,
        "priceRetailGbp": 995,
        "priceRetailEur": 1170.59,
        "priceRrpIncVat": 1194
      }
    ],
    "images": [
      "Images/kromaedge/kroma-silver-surfer-front.jpg",
      "Images/kromaedge/kroma-silver-surfer-back.jpg",
      "Images/kromaedge/kroma-silver-surfer-wave.jpg"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "Silver Chrome Spray with Topcoat Demonstration",
        "creator": "Eureka Auto",
        "url": "https://www.youtube.com/watch?v=4NAz3k5N6rk",
        "embedId": "4NAz3k5N6rk",
        "duration": "5:40",
        "badge": "Topcoat Guide"
      },
      {
        "platform": "youtube",
        "title": "Perfect Chrome in Minutes: Spray Chrome Mirror Finish with 2K Clear (DIY Method)",
        "creator": "Hype Universal",
        "url": "https://www.youtube.com/watch?v=ag3aDYxdKQ0",
        "embedId": "ag3aDYxdKQ0",
        "duration": "7:15",
        "badge": "Chrome Tutorial"
      }
    ],
    "summary": "Ultra-low turbidity 2K topcoat clear specifically formulated for Kroma Edge Mirror Chrome. Seals and protects mirror finishes with zero clouding, lifting, or solvent reactivation.",
    "benefits": [
      "100% Non-Clouding Optical Clarity: Specially balanced solvent formulation will not attack or rearrange the mirror chrome metallic flake layer.",
      "High Gloss & Scratch Resistance: Hardens to an automotive-grade 2K protective shell resistant to weathering and wash chemicals.",
      "Versatile Mix Ratio: 10:1 (Base : Hardener) + 70–100% Dedicated Thinner for glass-like flow out."
    ],
    "howItWorks": [
      "Step 1 - Flash Off Chrome: Allow Kroma Chrome coat to dry for minimum 30 minutes at 20°C (68°F).",
      "Step 2 - Tack Coat: Apply one very light dusting / tack coat of Dedicated Clear at 18–22 PSI. Allow 5 minutes flash.",
      "Step 3 - Wet Gloss Coat: Apply one full wet coat to achieve maximum gloss depth and UV protection."
    ],
    "inTheBox": [
      "Kroma Dedicated Topcoat Clear Base",
      "Kroma Clear Hardener",
      "Kroma High-Flow Optical Thinner"
    ]
  },
  {
    "id": "fk-2629",
    "brand": "Flake King",
    "category": "Dry Metal Flake Guns",
    "name": "Flake King Pro Series Kit",
    "sku": "FOMPRO",
    "priceGbp": 208.33,
    "priceEur": 243.75,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO GUN SYSTEM",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeriesKit2.jpg?fit=600%2C600&ssl=1",
    "description": "The Flake King Pro Series Kit is the ultimate dry metal flake solution for the professional custom painter. Housed in a rugged aluminium flight case, the kit includes all components required to assemble the Flake King 500 airbrush attachment, 550 mini gun, and 1000 full-size spray gun. Machined from aircraft-grade billet aluminium with red anodising.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOMPRO",
    "barcode": "5060733580007",
    "priceRetailGbp": 208.33,
    "priceRetailEur": 243.75,
    "priceRrpExVat": 208.33,
    "priceRrpIncVat": 249.99,
    "images": [
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeriesKit2.jpg?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries1.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries2.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries3.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries4.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries5.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries6.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries7.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/ProSeries8.png?fit=600%2C600&ssl=1"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "FLAKE KING PRO SET FULL REVIEW with bonus FLAKE & LACE LOWRIDER STYLE",
        "creator": "Dred fx Custom Paint",
        "url": "https://www.youtube.com/watch?v=pYKBnNwXiPs",
        "embedId": "pYKBnNwXiPs",
        "duration": "14:35",
        "badge": "Pro Review"
      },
      {
        "platform": "youtube",
        "title": "How To Spray Metal Flake Using The Flake King 1000 Dry Metal Flake Spray Gun",
        "creator": "Tony's Refinishing",
        "url": "https://www.youtube.com/watch?v=YmE-kCQLjvM",
        "embedId": "YmE-kCQLjvM",
        "duration": "8:42",
        "badge": "Master Tutorial"
      },
      {
        "platform": "youtube",
        "title": "How to metal flake with Flake King Guns.",
        "creator": "SM Designs Airbrush",
        "url": "https://www.youtube.com/watch?v=13SQPoGvjk8",
        "embedId": "13SQPoGvjk8",
        "duration": "12:15",
        "badge": "Pro Demonstration"
      }
    ],
    "summary": "The ultimate master custom painter system. Encompasses all three Flake King dry flake guns (500 Airbrush Attachment, 550 Mini Gun, and 1000 Full-Size Gun) in a heavy-duty CNC-cut aluminium flight case.",
    "benefits": [
      "All 3 Gun Configurations in 1 Case: Seamlessly switch between micro detail airbrush work (FK-500), mid-size parts (FK-550 Mini), and large automotive panels (FK-1000).",
      "Signature Red Anodised CNC Billet: Precision machined and anodised in Flake King's signature high-durability red finish.",
      "Maximum Workshop Versatility: Everything needed to tackle projects from guitars and helmets up to complete cars, boats, and large architectural installations.",
      "Save Over £45 vs Buying Individually: Includes complete nozzle sets, adaptors, air fittings, and sample jars."
    ],
    "howItWorks": [
      "Step 1 - Select Configuration: Choose the FK-500 for airbrush detail, FK-550 Mini for medium parts, or FK-1000 for full panels.",
      "Step 2 - Apply Over Wet Clear: Spray your target area with wet intercoat clear or binder, then spray flake dry at 10–15 PSI.",
      "Step 3 - Reclaim & Clearcoat: Blow off unbonded dry flake for reuse, then seal with 2K clearcoat."
    ],
    "inTheBox": [
      "Flake King 1000 Pro Gun Body with In-Line Valve & 3 Dispersion Nozzles",
      "Flake King 550 Mini Gun with 1/4\" to 1/8\" Airline Adaptor",
      "Flake King 500 Airbrush Adaptor Body (Iwata Eclipse Connector Included)",
      "2× Articulated Self-Levelling Barrels & Mounting Accessories",
      "3× Flake Jars (30g & 50g)",
      "Heavy-Duty Lockable Aluminium Flight Case with CNC Foam Inlay"
    ]
  },
  {
    "id": "fk-2610",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Show Krome Metal Flake",
    "sku": "show-krome-metal-flake-1",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2610.jpg",
    "description": "Show Krome Metal Flake. Available in .002″, .004″, .008″, .015″, .025″ & .040″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Ultra Small .002\"",
      "Small .008\"",
      "Medium .015\"",
      "Large .025\"",
      "XL .040\"",
      "DXL .060\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 314.4,
        "priceEur": 367.85,
        "priceRetailGbp": 314.4,
        "priceRetailEur": 367.85,
        "priceRrpExVat": 314.4,
        "priceRrpIncVat": 377.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 33.63,
        "priceEur": 39.35,
        "priceRetailGbp": 33.63,
        "priceRetailEur": 39.35,
        "priceRrpExVat": 33.63,
        "priceRrpIncVat": 40.35
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 11.08,
        "priceEur": 12.96,
        "priceRetailGbp": 11.08,
        "priceRetailEur": 12.96,
        "priceRrpExVat": 11.08,
        "priceRrpIncVat": 13.3
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 11.08,
        "priceEur": 12.96,
        "stockCode": "FKS015030",
        "barcode": "5060733580373",
        "priceRetailGbp": 11.08,
        "priceRetailEur": 12.96,
        "priceRrpExVat": 11.08,
        "priceRrpIncVat": 13.3,
        "sku": "FKS015030"
      },
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 33.63,
        "priceEur": 39.35,
        "stockCode": "FKS0150100",
        "barcode": "5060733580380",
        "priceRetailGbp": 33.63,
        "priceRetailEur": 39.35,
        "priceRrpExVat": 33.63,
        "priceRrpIncVat": 40.35,
        "sku": "FKS0150100"
      },
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 314.4,
        "priceEur": 367.85,
        "stockCode": "FKS01501000",
        "barcode": "5060733580397",
        "priceRetailGbp": 314.4,
        "priceRetailEur": 367.85,
        "priceRrpExVat": 314.4,
        "priceRrpIncVat": 377.28,
        "sku": "FKS01501000"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS0110030",
        "barcode": "5060733580403",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS0110030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS01100100",
        "barcode": "5060733580410",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS01100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 126.9,
        "priceEur": 148.47,
        "stockCode": "FKS011001000",
        "barcode": "5060733580427",
        "priceRetailGbp": 126.9,
        "priceRetailEur": 148.47,
        "priceRrpExVat": 126.9,
        "priceRrpIncVat": 152.28,
        "sku": "FKS011001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0120030",
        "barcode": "5060733580434",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0120030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS01200100",
        "barcode": "5060733580441",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS01200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS012001000",
        "barcode": "5060733580458",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS012001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0137530",
        "barcode": "5060733580465",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0137530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS01375100",
        "barcode": "5060733580472",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS01375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS013751000",
        "barcode": "5060733580489",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS013751000"
      },
      {
        "flakeSize": "XL .040\"",
        "rawFlakeSize": "xlarge",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0162530",
        "barcode": "5060733580496",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0162530"
      },
      {
        "flakeSize": "XL .040\"",
        "rawFlakeSize": "xlarge",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS01625100",
        "barcode": "5060733580502",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS01625100"
      },
      {
        "flakeSize": "XL .040\"",
        "rawFlakeSize": "xlarge",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS016251000",
        "barcode": "5060733580519",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS016251000"
      },
      {
        "flakeSize": "DXL .060\"",
        "rawFlakeSize": "dxl",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS01101530",
        "barcode": "5060733580526",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS01101530"
      },
      {
        "flakeSize": "DXL .060\"",
        "rawFlakeSize": "dxl",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS011015100",
        "barcode": "5060733580533",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS011015100"
      },
      {
        "flakeSize": "DXL .060\"",
        "rawFlakeSize": "dxl",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS0110151000",
        "barcode": "5060733580540",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS0110151000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2610.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2610.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "Testing the Flake King 1000 and Spraying Holographic Flake",
        "creator": "KADxM",
        "url": "https://www.youtube.com/watch?v=GZlRF6icaR8",
        "embedId": "GZlRF6icaR8",
        "duration": "6:30",
        "badge": "Application Demo"
      },
      {
        "platform": "youtube",
        "title": "How To Spray Metal Flake Using The Flake King 1000 Dry Metal Flake Spray Gun",
        "creator": "Tony's Refinishing",
        "url": "https://www.youtube.com/watch?v=YmE-kCQLjvM",
        "embedId": "YmE-kCQLjvM",
        "duration": "8:42",
        "badge": "Master Class"
      }
    ]
  },
  {
    "id": "fk-2603",
    "brand": "Flake King",
    "category": "Dry Metal Flake Guns",
    "name": "Flake King 500 – Dry Metal Flake Airbrush Attachment",
    "sku": "FOM500",
    "priceGbp": 83.33,
    "priceEur": 97.5,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO GUN SYSTEM",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5001.png?fit=600%2C600&ssl=1",
    "description": "The Flake King 500 transforms your existing airbrush into a professional dry flake gun. Ideal for small-to-medium custom projects including helmets, guitars, skateboards, and model kits. Powered entirely by your airbrush compressor at 10–15 PSI, it sprays dry flake into wet binder with zero contamination to your airbrush needle or nozzle.",
    "sizes": [
      "Iwata Eclipse BCS/HPC",
      "Iwata Revolution BCR",
      "Iwata Neo",
      "Badger 105/360",
      "Harder & Steenbeck",
      "Paasche Talon"
    ],
    "packSizes": [],
    "hasOptions": true,
    "hasFullMatrix": true,
    "stockCode": "FOM500",
    "barcode": "5060733580076",
    "priceRetailGbp": 83.33,
    "priceRetailEur": 97.5,
    "priceRrpExVat": 83.33,
    "priceRrpIncVat": 99.99,
    "images": [
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5001.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5002.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5003.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5004.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5005.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5006.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5007.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5008.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM500A.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM500B.png?fit=600%2C600&ssl=1"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "Apply Dry Flake with Your Iwata NEO Airbrush using Flake King 500",
        "creator": "SprayGunner Com",
        "url": "https://www.youtube.com/watch?v=exKU91XDlek",
        "embedId": "exKU91XDlek",
        "duration": "4:18",
        "badge": "Airbrush Tutorial"
      },
      {
        "platform": "youtube",
        "title": "First Use Of My Flake King 500 Airbrush Adaptor",
        "creator": "Ttxela Adventures!",
        "url": "https://www.youtube.com/watch?v=cTMq71sZ7LE",
        "embedId": "cTMq71sZ7LE",
        "duration": "7:22",
        "badge": "Live Test"
      },
      {
        "platform": "youtube",
        "title": "I Bought A Flake King 500 Airbrush Adaptor - Full Overview",
        "creator": "Ttxela Adventures!",
        "url": "https://www.youtube.com/watch?v=45fGgDbDkSg",
        "embedId": "45fGgDbDkSg",
        "duration": "5:40",
        "badge": "Product Review"
      }
    ],
    "summary": "Converts your standard dual-action airbrush into a precision dry flake applicator. Ideal for custom helmets, skateboards, RC bodies, guitars, and fine studio artwork.",
    "benefits": [
      "Zero Airbrush Contamination: Never put metallic flake through your fine 0.3mm or 0.5mm airbrush fluid nozzle again. Flake is applied completely dry onto wet intercoat clear.",
      "Runs On Standard Airbrush Compressors: Requires only 10–15 PSI, making it 100% compatible with compact studio and garage compressors.",
      "Interchangeable Precision Adaptors: Precision CNC brass adaptors available for Iwata, Badger, Harder & Steenbeck, and Paasche airbrushes.",
      "Instant Push-Fit Mounting: Slides directly over the air cap with an internal airtight seal. Swap between detail airbrushing and flaking in seconds.",
      "Direct 30g/50g Jar Mount: Uses standard screw-on Flake King jars for mess-free handling and rapid color switches."
    ],
    "howItWorks": [
      "Step 1 - Prepare Substrate: Spray your artwork and apply a wet coat of airbrush intercoat clear or binder.",
      "Step 2 - Attach & Spray: Slip the Flake King 500 onto your airbrush nozzle and spray dry flake at 10–15 PSI onto the wet clear.",
      "Step 3 - Seal: Remove attachment, blow off excess dry flake, and lock down with final clearcoat."
    ],
    "inTheBox": [
      "Flake King 500 Push-Fit Body & Jar Assembly",
      "1× Airbrush Connector of Your Choice (Iwata, H&S, Badger, or Paasche)",
      "1× 30g Flake King Jar",
      "Precision O-Ring Seal Kit & Instruction Manual"
    ]
  },
  {
    "id": "fk-2602",
    "brand": "Flake King",
    "category": "Dry Metal Flake Guns",
    "name": "Flake King 1000 Dry Metal Flake Gun",
    "sku": "FOM1000",
    "priceGbp": 108.33,
    "priceEur": 126.75,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO GUN SYSTEM",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10001.png?fit=600%2C600&ssl=1",
    "description": "The Flake King 1000 is the industry-standard dry metal flake applicator gun used by professional custom painters worldwide. Engineered to spray dry flake directly into wet intercoat clear, it eliminates fluid gun contamination, saves up to 70% in clearcoat, and prevents clumping. Features patented Venturi agitation, an in-line metering valve, and 3 color-coded nozzles for total application control.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM1000",
    "barcode": "5060733580014",
    "priceRetailGbp": 108.33,
    "priceRetailEur": 126.75,
    "priceRrpExVat": 108.33,
    "priceRrpIncVat": 129.99,
    "images": [
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10001.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10002.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10003.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10004.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10005.png?fit=600%2C600&ssl=1"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "How To Spray Metal Flake Using The Flake King 1000 Dry Metal Flake Spray Gun",
        "creator": "Tony's Refinishing",
        "url": "https://www.youtube.com/watch?v=YmE-kCQLjvM",
        "embedId": "YmE-kCQLjvM",
        "duration": "8:42",
        "badge": "Master Tutorial"
      },
      {
        "platform": "youtube",
        "title": "How to metal flake with Flake King Guns.",
        "creator": "SM Designs Airbrush",
        "url": "https://www.youtube.com/watch?v=13SQPoGvjk8",
        "embedId": "13SQPoGvjk8",
        "duration": "12:15",
        "badge": "Pro Demonstration"
      },
      {
        "platform": "youtube",
        "title": "Testing the Flake King 1000 and Spraying Holographic Flake",
        "creator": "KADxM",
        "url": "https://www.youtube.com/watch?v=GZlRF6icaR8",
        "embedId": "GZlRF6icaR8",
        "duration": "6:30",
        "badge": "Live Test"
      },
      {
        "platform": "youtube",
        "title": "Flake King 1000 Dry Flake Gun Video Short",
        "creator": "Flake King",
        "url": "https://www.youtube.com/watch?v=XlaytQc3RcI",
        "embedId": "XlaytQc3RcI",
        "duration": "0:59",
        "badge": "Official Demo"
      }
    ],
    "summary": "The industry-standard professional dry flake applicator gun. Engineered to spray dry metal flake directly into wet intercoat clear with zero fluid gun contamination, up to 70% clearcoat savings, and zero clumping.",
    "benefits": [
      "Zero Gun Contamination: 100% dry flake application. Flake never enters your fluid nozzle, needle, or fluid passages, eliminating hours of gun teardown and cleanup.",
      "Save Up To 70% Clearcoat & Sanding: Flake lays down completely flat upon impact into wet binder — no heavy bury coats or endless block sanding required.",
      "Patented Venturi Agitation (10–15 PSI): Internal air agitation continuously fluidizes the flake, drawing it out smoothly with zero spitting or \"flurries\".",
      "3 Color-Coded Precision Nozzles: Includes fine, medium, and wide dispersion nozzles for effortless blending and panel coverage from motorcycle helmets to full vehicles.",
      "Dual-Mode Articulated Barrel: Set the barrel to self-levelling or locked rigid depending on spraying angles and contours.",
      "Direct-to-Jar Threading: Screws directly onto standard 50g & 100g Flake King jars for mess-free, instant color changes."
    ],
    "howItWorks": [
      "Step 1 - Base & Wet Clear: Apply your base color, then spray a wet coat of intercoat clear or binder.",
      "Step 2 - Apply Dry Flake: While the clear is wet, spray dry flake at 10–15 PSI using the Flake King 1000. Flake instantly locks flat into the wet film.",
      "Step 3 - Blow Off & Clear: Allow binder to flash, lightly blow off loose excess dry flake (which can be reclaimed!), and seal with 2–3 coats of 2K clearcoat."
    ],
    "inTheBox": [
      "Flake King 1000 Gun Body with In-Line Metering Valve",
      "3× Color-Coded Precision Dispersion Nozzles (Fine, Medium, Wide)",
      "Articulated Self-Levelling Barrel Assembly",
      "1× 50g Flake King Storage Jar",
      "Standard 1/4\" BSP European Quick-Connect Air Fitting",
      "Official Flake King Technical User Guide"
    ]
  },
  {
    "id": "fk-2600",
    "brand": "Flake King",
    "category": "Flake King Gun Accessories",
    "name": "FOM 1000/1050 50g Jar & Lid",
    "sku": "FOM50gJarLid",
    "priceGbp": 1.24,
    "priceEur": 1.45,
    "inStock": true,
    "isPreOrder": false,
    "badge": "GENUINE ACCESSORY",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/07/FOM1000-50gJarLid.jpg?fit=1200%2C1200&ssl=1",
    "description": "Replacement 50g Jar & Lid for the FOM 1000 & 1050 Gun",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM50gJarLid",
    "barcode": "5060733583169",
    "priceRetailGbp": 1.24,
    "priceRetailEur": 1.45,
    "priceRrpExVat": 1.24,
    "priceRrpIncVat": 1.49
  },
  {
    "id": "fk-2598",
    "brand": "Flake King",
    "category": "Flake King Gun Accessories",
    "name": "FOM 500/550 Spare 30g Jar & Lid",
    "sku": "FOM500JL",
    "priceGbp": 1.1,
    "priceEur": 1.29,
    "inStock": true,
    "isPreOrder": false,
    "badge": "GENUINE ACCESSORY",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/07/FOM500_550JarLid-scaled.jpg?fit=2560%2C2560&ssl=1",
    "description": "Replacement plastic 30g jar to fit the FOM500 Airbrush & FOM550 Mini Gun",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM500JL",
    "barcode": "5060733580137",
    "priceRetailGbp": 1.1,
    "priceRetailEur": 1.29,
    "priceRrpExVat": 1.1,
    "priceRrpIncVat": 1.32
  },
  {
    "id": "fk-2542",
    "brand": "Flake King",
    "category": "Dry Metal Flake Guns",
    "name": "Flake O Matic 1000",
    "sku": "FOM1000",
    "priceGbp": 108.33,
    "priceEur": 126.75,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO GUN SYSTEM",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FoMDeluxe2.png?fit=500%2C343&ssl=1",
    "description": "The Flake o Matic has grown up and has now been superseded by the Flake King 1000\nPlease click here to see the new gun.\nThe Flake O Matic 1000 was designed to be an efficient way of applying metal flake.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM1000",
    "barcode": "5060733580014",
    "priceRetailGbp": 108.33,
    "priceRetailEur": 126.75,
    "priceRrpExVat": 108.33,
    "priceRrpIncVat": 129.99
  },
  {
    "id": "fk-2524",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Show Krome Metal Flake",
    "sku": "kromatic-show-krome-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2524.jpg",
    "description": "FKK01 Kromatic Show Krome Metal Flake. Available in .002″, .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Ultra Small .002\"",
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 626.66,
        "priceEur": 733.19,
        "priceRetailGbp": 626.66,
        "priceRetailEur": 733.19,
        "priceRrpExVat": 626.66,
        "priceRrpIncVat": 751.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 64.88,
        "priceEur": 75.91,
        "priceRetailGbp": 64.88,
        "priceRetailEur": 75.91,
        "priceRrpExVat": 64.88,
        "priceRrpIncVat": 77.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 20.46,
        "priceEur": 23.94,
        "priceRetailGbp": 20.46,
        "priceRetailEur": 23.94,
        "priceRrpExVat": 20.46,
        "priceRrpIncVat": 24.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 64.88,
        "priceEur": 75.91,
        "stockCode": "FKK0150100",
        "barcode": "5060733582421",
        "priceRetailGbp": 64.88,
        "priceRetailEur": 75.91,
        "priceRrpExVat": 64.88,
        "priceRrpIncVat": 77.85,
        "sku": "FKK0150100"
      },
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 20.46,
        "priceEur": 23.94,
        "stockCode": "FKK015030",
        "barcode": "5060733582414",
        "priceRetailGbp": 20.46,
        "priceRetailEur": 23.94,
        "priceRrpExVat": 20.46,
        "priceRrpIncVat": 24.55,
        "sku": "FKK015030"
      },
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 626.66,
        "priceEur": 733.19,
        "stockCode": "FKK01501000",
        "barcode": "5060733582438",
        "priceRetailGbp": 626.66,
        "priceRetailEur": 733.19,
        "priceRrpExVat": 626.66,
        "priceRrpIncVat": 751.99,
        "sku": "FKK01501000"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 9.99,
        "priceEur": 11.69,
        "stockCode": "FKK0110030",
        "barcode": "5060733582445",
        "priceRetailGbp": 9.99,
        "priceRetailEur": 11.69,
        "priceRrpExVat": 9.99,
        "priceRrpIncVat": 11.99,
        "sku": "FKK0110030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 29.99,
        "priceEur": 35.09,
        "stockCode": "FKK01100100",
        "barcode": "5060733582452",
        "priceRetailGbp": 29.99,
        "priceRetailEur": 35.09,
        "priceRrpExVat": 29.99,
        "priceRrpIncVat": 35.99,
        "sku": "FKK01100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 291.66,
        "priceEur": 341.24,
        "stockCode": "FKK011001000",
        "barcode": "5060733582469",
        "priceRetailGbp": 291.66,
        "priceRetailEur": 341.24,
        "priceRrpExVat": 291.66,
        "priceRrpIncVat": 349.99,
        "sku": "FKK011001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0120030",
        "barcode": "5060733582476",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0120030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK01200100",
        "barcode": "5060733582483",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK01200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK012001000",
        "barcode": "5060733582490",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK012001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0137530",
        "barcode": "5060733582506",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0137530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK01375100",
        "barcode": "5060733582513",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK01375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK013751000",
        "barcode": "5060733582520",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK013751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2524.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2524.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ],
    "stockCode": "FKK01"
  },
  {
    "id": "fk-2426",
    "brand": "Flake King",
    "category": "Flake King Gun Accessories",
    "name": "Flake King 1000 Nozzle",
    "sku": "flake-king-1000-nozzle",
    "priceGbp": 5.55,
    "priceEur": 6.49,
    "inStock": true,
    "isPreOrder": false,
    "badge": "GENUINE ACCESSORY",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FanNozzles.jpg?fit=600%2C600&ssl=1",
    "description": "Available in small, medium & large.\nFan nozzles that can be bought individually or as a pack.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM1000NZS",
    "barcode": "5060733580038",
    "priceRetailGbp": 5.55,
    "priceRetailEur": 6.49,
    "priceRrpExVat": 5.55,
    "priceRrpIncVat": 6.66,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "Small Nozzle",
        "stockCode": "FOM1000NZS",
        "barcode": "5060733580038",
        "priceGbp": 5.55,
        "priceEur": 6.49,
        "priceRetailGbp": 5.55,
        "priceRetailEur": 6.49,
        "priceRrpExVat": 5.55,
        "priceRrpIncVat": 6.66,
        "sku": "FOM1000NZS"
      },
      {
        "packSize": "Medium Nozzle",
        "stockCode": "FOM1000NZM",
        "barcode": "5060733580045",
        "priceGbp": 5.55,
        "priceEur": 6.49,
        "priceRetailGbp": 5.55,
        "priceRetailEur": 6.49,
        "priceRrpExVat": 5.55,
        "priceRrpIncVat": 6.66,
        "sku": "FOM1000NZM"
      },
      {
        "packSize": "Large Nozzle",
        "stockCode": "FOM1000NZL",
        "barcode": "5060733580052",
        "priceGbp": 5.55,
        "priceEur": 6.49,
        "priceRetailGbp": 5.55,
        "priceRetailEur": 6.49,
        "priceRrpExVat": 5.55,
        "priceRrpIncVat": 6.66,
        "sku": "FOM1000NZL"
      }
    ]
  },
  {
    "id": "fk-2423",
    "brand": "Flake King",
    "category": "Flake King Gun Accessories",
    "name": "FOM 1000/1050 100g Jar and Standard Lid",
    "sku": "FOM1000Jar",
    "priceGbp": 1.65,
    "priceEur": 1.93,
    "inStock": true,
    "isPreOrder": false,
    "badge": "GENUINE ACCESSORY",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM1000JarLid-scaled.jpg?fit=2560%2C2560&ssl=1",
    "description": "Replacement Jar and Lid for the Flake King 1000 & 1050.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM1000Jar",
    "barcode": "5060733580021",
    "priceRetailGbp": 1.65,
    "priceRetailEur": 1.93,
    "priceRrpExVat": 1.65,
    "priceRrpIncVat": 1.98
  },
  {
    "id": "fk-2415",
    "brand": "Flake King",
    "category": "Wet Products",
    "name": "FK100 Prime Black Base",
    "sku": "fk100-prime-black-base",
    "priceGbp": 10.28,
    "priceEur": 12.03,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO WET BINDER",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FK100FamilyWeb_1.jpg?fit=600%2C600&ssl=1",
    "description": "Available in 100ml, 500ml & 1 Litre Bottles\nWhen we considered the perfect colour for our Metal Flake, we had to look no further than FK100 our prime black base that offers incredible adhesion to the wide ranging array of primers on the market today.\nAgain, as it’s water based, it’s better for the environment, inert and will not react with previously applied products it also easier to ship (worldwide)\nPrime Black Base will adhere to properly prepared surfaces such as existing finishes, primer, plastic, vinyl, fibreglass, wood and most substrates.\nPrime black base is be the perfect companion for our FK50 Surface binder to adhere to.",
    "sizes": [
      "100ml",
      "500ml",
      "1000ml (1 Litre)"
    ],
    "packSizes": [
      "100ml",
      "500ml",
      "1000ml (1 Litre)"
    ],
    "hasOptions": true,
    "stockCode": "FK100100",
    "barcode": "5060733583152",
    "priceRetailGbp": 10.28,
    "priceRetailEur": 12.03,
    "priceRrpExVat": 10.28,
    "priceRrpIncVat": 12.34,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "100ml",
        "stockCode": "FK100100",
        "barcode": "5060733583152",
        "priceGbp": 10.28,
        "priceEur": 12.03,
        "priceRetailGbp": 10.28,
        "priceRetailEur": 12.03,
        "priceRrpExVat": 10.28,
        "priceRrpIncVat": 12.34,
        "sku": "FK100100"
      },
      {
        "packSize": "500ml",
        "stockCode": "FK100500",
        "barcode": "5060733583176",
        "priceGbp": 45.86,
        "priceEur": 53.66,
        "priceRetailGbp": 45.86,
        "priceRetailEur": 53.66,
        "priceRrpExVat": 45.86,
        "priceRrpIncVat": 55.03,
        "sku": "FK100500"
      },
      {
        "packSize": "1000ml",
        "stockCode": "FK1001000",
        "barcode": "5060733583183",
        "priceGbp": 104.72,
        "priceEur": 122.52,
        "priceRetailGbp": 104.72,
        "priceRetailEur": 122.52,
        "priceRrpExVat": 104.72,
        "priceRrpIncVat": 125.66,
        "sku": "FK1001000"
      }
    ]
  },
  {
    "id": "fk-2409",
    "brand": "Flake King",
    "category": "Wet Products",
    "name": "FK55 Thinner",
    "sku": "fk55-thinner",
    "priceGbp": 5.6,
    "priceEur": 6.55,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO WET BINDER",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FK55FamilyWeb.jpg?fit=600%2C600&ssl=1",
    "description": "Available in 50ml & 100ml\nThis is our go to thinner for both our FK50 Surface Binder and our FK100 Prime Base. It can be added to a maximum of 10% volume.\nIt will also be our standard thinners for all new wet products moving forward.",
    "sizes": [
      "50ml",
      "100ml"
    ],
    "packSizes": [
      "50ml",
      "100ml"
    ],
    "hasOptions": true,
    "stockCode": "FK5550",
    "barcode": "5060733580342",
    "priceRetailGbp": 5.6,
    "priceRetailEur": 6.55,
    "priceRrpExVat": 5.6,
    "priceRrpIncVat": 6.72,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "50ml",
        "stockCode": "FK5550",
        "barcode": "5060733580342",
        "priceGbp": 5.6,
        "priceEur": 6.55,
        "priceRetailGbp": 5.6,
        "priceRetailEur": 6.55,
        "priceRrpExVat": 5.6,
        "priceRrpIncVat": 6.72,
        "sku": "FK5550"
      },
      {
        "packSize": "100ml",
        "stockCode": "FK55100",
        "barcode": "5060733580359",
        "priceGbp": 11.04,
        "priceEur": 12.92,
        "priceRetailGbp": 11.04,
        "priceRetailEur": 12.92,
        "priceRrpExVat": 11.04,
        "priceRrpIncVat": 13.25,
        "sku": "FK55100"
      }
    ]
  },
  {
    "id": "fk-2401",
    "brand": "Flake King",
    "category": "Wet Products",
    "name": "FK50 Surface Binder",
    "sku": "fk50-surface-binder",
    "priceGbp": 4.99,
    "priceEur": 5.84,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO WET BINDER",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FK50Familyweb.jpg?fit=600%2C600&ssl=1",
    "description": "Available in 100ml, 500ml & 1 Litre Bottles\nFK50 Surface binder is a water based adhesion product, that can applied by brush, dabbed on with a sponge or sprayed on with Spray gun or Airbrush (when thinned with FK55 Thinners).\nDeveloped to stay open longer than a typical solvent or existing water based product with reduced potential of sagging when applied in a medium to wet coat. Its primary use is for the application of our Dry Metal Flakes (Industrial/Commercial Glitters) and our dry blended metal powders.\nWhy is it better than, for example a solvent binder or 2k clear?\nWell as it’s water based, it’s better for the environment, inert will not react with previously applied products, easier to ship (worldwide) and there are no sensible limitations on how many coats that can be applied (within reason).\nIt also produces a nice clean edge, for masking removal, allowing you to now be able to produce coloured flake designs rather than traditional methods of silver base and coloured “candy” dyes on top. Coloured flake will last longer in direct sunlight than candy dye based products.\nAn additional bonus the FK50 Surface binder when applied over a complete flaked area, reduces the amount of clear coat required.\nFK50 will adhere to properly prepared surfaces such as existing finishes, primer, plastic, vinyl, fibreglass, wood and most substrates.",
    "sizes": [
      "50ml",
      "100ml",
      "500ml",
      "1000ml (1 Litre)"
    ],
    "packSizes": [
      "50ml",
      "100ml",
      "500ml",
      "1000ml (1 Litre)"
    ],
    "hasOptions": true,
    "stockCode": "FK5050",
    "barcode": "5060733580298",
    "priceRetailGbp": 4.99,
    "priceRetailEur": 5.84,
    "priceRrpExVat": 4.99,
    "priceRrpIncVat": 5.99,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "50ml",
        "stockCode": "FK5050",
        "barcode": "5060733580298",
        "priceGbp": 4.99,
        "priceEur": 5.84,
        "priceRetailGbp": 4.99,
        "priceRetailEur": 5.84,
        "priceRrpExVat": 4.99,
        "priceRrpIncVat": 5.99,
        "sku": "FK5050"
      },
      {
        "packSize": "100ml",
        "stockCode": "FK50100",
        "barcode": "5060733580304",
        "priceGbp": 9.25,
        "priceEur": 10.82,
        "priceRetailGbp": 9.25,
        "priceRetailEur": 10.82,
        "priceRrpExVat": 9.25,
        "priceRrpIncVat": 11.1,
        "sku": "FK50100"
      },
      {
        "packSize": "500ml",
        "stockCode": "FK50500",
        "barcode": "5060733580328",
        "priceGbp": 40.36,
        "priceEur": 47.22,
        "priceRetailGbp": 40.36,
        "priceRetailEur": 47.22,
        "priceRrpExVat": 40.36,
        "priceRrpIncVat": 48.43,
        "sku": "FK50500"
      },
      {
        "packSize": "1000ml",
        "stockCode": "FK501000",
        "barcode": "5060733580335",
        "priceGbp": 79.72,
        "priceEur": 93.27,
        "priceRetailGbp": 79.72,
        "priceRetailEur": 93.27,
        "priceRrpExVat": 79.72,
        "priceRrpIncVat": 95.66,
        "sku": "FK501000"
      }
    ]
  },
  {
    "id": "fk-2392",
    "brand": "Flake King",
    "category": "Masking Products",
    "name": "UltiMask Crepe Masking Tape",
    "sku": "ultimask-crepe-masking-tape",
    "priceGbp": 1.4,
    "priceEur": 1.65,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FINE LINE PRO",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/UltiMaskCrepe18mmB.gif?fit=600%2C600&ssl=1",
    "description": "Available in 18mm, 24mm, 36mm & 48mm widths\nUltiMask Crepe Masking Tape is a general all-round crepe tape for masking off areas when spraying vehicles. It is ideally suited to use with other Flake King products, with a strong adhesion and is heat-resistant to temperatures of 80C/176F. UltiMask Crepe Masking Tape can be easily removed, leaving no residue and is available in widths from 19mm to 48mm. UltiMask Crepe Masking Tape is the perfect high-quality everyday tape. Supplied individually packed to keep clean and dry.",
    "sizes": [
      "18mm x 50m",
      "24mm x 50m",
      "36mm x 50m",
      "48mm x 50m"
    ],
    "packSizes": [
      "18mm x 50m",
      "24mm x 50m",
      "36mm x 50m",
      "48mm x 50m"
    ],
    "hasOptions": true,
    "tapeWidths": [
      "18mm x 50m",
      "24mm x 50m",
      "36mm x 50m",
      "48mm x 50m"
    ],
    "tapePriceMatrix": [
      {
        "width": "18mm x 50m",
        "priceGbp": 1.4,
        "priceEur": 1.65,
        "priceRrpIncVat": 1.68,
        "stockCode": "TPCP18",
        "sku": "TPCP18",
        "barcode": "5060733583145"
      },
      {
        "width": "24mm x 50m",
        "priceGbp": 1.8,
        "priceEur": 2.12,
        "priceRrpIncVat": 2.16,
        "stockCode": "TPCP24",
        "sku": "TPCP24",
        "barcode": "5060733580250"
      },
      {
        "width": "36mm x 50m",
        "priceGbp": 2.7,
        "priceEur": 3.18,
        "priceRrpIncVat": 3.24,
        "stockCode": "TPCP36",
        "sku": "TPCP36",
        "barcode": "5060733580267"
      },
      {
        "width": "48mm x 50m",
        "priceGbp": 3.6,
        "priceEur": 4.24,
        "priceRrpIncVat": 4.32,
        "stockCode": "TPCP48",
        "sku": "TPCP48",
        "barcode": "5060733580274"
      }
    ],
    "hasTapeOptions": true,
    "stockCode": "TPCP18",
    "barcode": "5060733583145",
    "priceRetailGbp": 1.4,
    "priceRetailEur": 1.64,
    "priceRrpExVat": 1.4,
    "priceRrpIncVat": 1.68,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "18mm x 50m",
        "stockCode": "TPCP18",
        "barcode": "5060733583145",
        "priceGbp": 1.4,
        "priceEur": 1.64,
        "priceRetailGbp": 1.4,
        "priceRetailEur": 1.64,
        "priceRrpExVat": 1.4,
        "priceRrpIncVat": 1.68,
        "sku": "TPCP18"
      },
      {
        "packSize": "24mm x 50m",
        "stockCode": "TPCP24",
        "barcode": "5060733580250",
        "priceGbp": 1.8,
        "priceEur": 2.11,
        "priceRetailGbp": 1.8,
        "priceRetailEur": 2.11,
        "priceRrpExVat": 1.8,
        "priceRrpIncVat": 2.16,
        "sku": "TPCP24"
      },
      {
        "packSize": "36mm x 50m",
        "stockCode": "TPCP36",
        "barcode": "5060733580267",
        "priceGbp": 2.7,
        "priceEur": 3.16,
        "priceRetailGbp": 2.7,
        "priceRetailEur": 3.16,
        "priceRrpExVat": 2.7,
        "priceRrpIncVat": 3.24,
        "sku": "TPCP36"
      },
      {
        "packSize": "48mm x 50m",
        "stockCode": "TPCP48",
        "barcode": "5060733580274",
        "priceGbp": 3.6,
        "priceEur": 4.21,
        "priceRetailGbp": 3.6,
        "priceRetailEur": 4.21,
        "priceRrpExVat": 3.6,
        "priceRrpIncVat": 4.32,
        "sku": "TPCP48"
      }
    ]
  },
  {
    "id": "fk-2380",
    "brand": "Flake King",
    "category": "Masking Products",
    "name": "Prime Flat Line Masking Tape",
    "sku": "prime-flat-line-masking-tape",
    "priceGbp": 1.66,
    "priceEur": 1.95,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FINE LINE PRO",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FlatLine6mm.png?fit=600%2C600&ssl=1",
    "description": "Prime Flat Line Masking Tape\nAvailable in 6mm, 9mm, 12mm, 24mm & 48mm widths\nPrime Flat Line Orange is our precision masking solution for masking rubbers, plastics, mouldings, trims, canvass and artboards – both paper and synthetic airbrush papers. Summed up it is a flat non-bleed tape that adheres to surfaces that conventional masking tape would not!\nConstructed from “washi” or better known as rice paper, this non-bleed tape is suitable for fine-line work as well as general masking. Developed for high end industrial, commercial model makers, scenery, film, automotive, and artists applications. Ideal for placing over existing artwork or vinyl fine lines as the tape is so translucent it allows you see through it to cut and remove the necessary areas.\nThe flexible, water-proof, advanced acrylic adhesive means that it will adhere to surfaces that standard masking tape would otherwise not; resistant to 110C/230F, available in widths from 6mm upwards. However, we can produce this to any width required subject to quantity.",
    "sizes": [
      "6mm x 50m",
      "9mm x 50m",
      "12mm x 50m",
      "24mm x 50m",
      "48mm x 50m"
    ],
    "packSizes": [
      "6mm x 50m",
      "9mm x 50m",
      "12mm x 50m",
      "24mm x 50m",
      "48mm x 50m"
    ],
    "hasOptions": true,
    "tapeWidths": [
      "6mm x 50m",
      "9mm x 50m",
      "12mm x 50m",
      "24mm x 50m",
      "48mm x 50m"
    ],
    "tapePriceMatrix": [
      {
        "width": "6mm x 50m",
        "priceGbp": 1.66,
        "priceEur": 1.95,
        "priceRrpIncVat": 1.99,
        "stockCode": "TPFL6",
        "sku": "TPFL6",
        "barcode": "5060733583299"
      },
      {
        "width": "9mm x 50m",
        "priceGbp": 1.91,
        "priceEur": 2.25,
        "priceRrpIncVat": 2.29,
        "stockCode": "TPFL9",
        "sku": "TPFL9",
        "barcode": "5060733583305"
      },
      {
        "width": "12mm x 50m",
        "priceGbp": 2.08,
        "priceEur": 2.45,
        "priceRrpIncVat": 2.49,
        "stockCode": "TPFL12",
        "sku": "TPFL12",
        "barcode": "5060733583312"
      },
      {
        "width": "24mm x 50m",
        "priceGbp": 3.33,
        "priceEur": 3.92,
        "priceRrpIncVat": 3.99,
        "stockCode": "TPFL24",
        "sku": "TPFL24",
        "barcode": "5060733583329"
      },
      {
        "width": "48mm x 50m",
        "priceGbp": 5.83,
        "priceEur": 6.86,
        "priceRrpIncVat": 6.99,
        "stockCode": "TPFL48",
        "sku": "TPFL48",
        "barcode": "5060733583336"
      }
    ],
    "hasTapeOptions": true,
    "stockCode": "TPFL6",
    "barcode": "5060733583299",
    "priceRetailGbp": 1.66,
    "priceRetailEur": 1.94,
    "priceRrpExVat": 1.66,
    "priceRrpIncVat": 1.99,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "6mm x 50m",
        "stockCode": "TPFL6",
        "barcode": "5060733583299",
        "priceGbp": 1.66,
        "priceEur": 1.94,
        "priceRetailGbp": 1.66,
        "priceRetailEur": 1.94,
        "priceRrpExVat": 1.66,
        "priceRrpIncVat": 1.99,
        "sku": "TPFL6"
      },
      {
        "packSize": "9mm x 50m",
        "stockCode": "TPFL9",
        "barcode": "5060733583305",
        "priceGbp": 1.91,
        "priceEur": 2.23,
        "priceRetailGbp": 1.91,
        "priceRetailEur": 2.23,
        "priceRrpExVat": 1.91,
        "priceRrpIncVat": 2.29,
        "sku": "TPFL9"
      },
      {
        "packSize": "12mm x 50m",
        "stockCode": "TPFL12",
        "barcode": "5060733583312",
        "priceGbp": 2.08,
        "priceEur": 2.43,
        "priceRetailGbp": 2.08,
        "priceRetailEur": 2.43,
        "priceRrpExVat": 2.08,
        "priceRrpIncVat": 2.49,
        "sku": "TPFL12"
      },
      {
        "packSize": "24mm x 50m",
        "stockCode": "TPFL24",
        "barcode": "5060733583329",
        "priceGbp": 3.33,
        "priceEur": 3.9,
        "priceRetailGbp": 3.33,
        "priceRetailEur": 3.9,
        "priceRrpExVat": 3.33,
        "priceRrpIncVat": 3.99,
        "sku": "TPFL24"
      },
      {
        "packSize": "48mm x 50m",
        "stockCode": "TPFL48",
        "barcode": "5060733583336",
        "priceGbp": 5.83,
        "priceEur": 6.82,
        "priceRetailGbp": 5.83,
        "priceRetailEur": 6.82,
        "priceRrpExVat": 5.83,
        "priceRrpIncVat": 6.99,
        "sku": "TPFL48"
      }
    ]
  },
  {
    "id": "fk-2375",
    "brand": "Flake King",
    "category": "Masking Products",
    "name": "Prime Orange Fine Line Mixed Set",
    "sku": "TPORMix",
    "priceGbp": 15.83,
    "priceEur": 18.52,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FINE LINE PRO",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/WebOrangeProSet_1.jpg?fit=600%2C600&ssl=1",
    "description": "Prime Orange Fine Line Mixed Set\nSizes included: 1 x 1mm, 1 x 2mm, 2 x 3mm\nOur Prime Orange Fine Line Tape uses thermally stabilised PVC backing with a rubber based pressure sensitive adhesive. Thinner and more translucent than other Fine Line Tapes making it ideal for seeing through to painted surfaces. Like our prime green fine line it is extremely versatile, perfect for intricate, delicate and multi-layer masking perfect for undulating surfaces and capable of tight radius curves. Developed for high end industrial, commercial model makers, scenery, film and automotive applications. Heat resistant to temperatures up to 138°C/280°F for at least 45 minutes; after painting, it can be cleanly removed leaving a defined line with no adhesive residue.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "stockCode": "TPORMix",
    "barcode": "5060733583282",
    "priceRetailGbp": 15.83,
    "priceRetailEur": 18.52,
    "priceRrpExVat": 15.83,
    "priceRrpIncVat": 18.99
  },
  {
    "id": "fk-2366",
    "brand": "Flake King",
    "category": "Masking Products",
    "name": "Prime Orange Fine Line",
    "sku": "prime-orange-fine-line",
    "priceGbp": 2.91,
    "priceEur": 3.42,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FINE LINE PRO",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/Orange1mm.png?fit=600%2C600&ssl=1",
    "description": "Available in 1mm, 2mm, 3mm & 6mm widths\nOur Prime Orange Fine Line Tape uses thermally stabilised PVC backing with a rubber based pressure sensitive adhesive. Thinner and more translucent than other Fine Line Tapes making it ideal for seeing through to painted surfaces. Like our prime green fine line it is extremely versatile, perfect for intricate, delicate and multi-layer masking perfect for undulating surfaces and capable of tight radius curves. Developed for high end industrial, commercial model makers, scenery, film and automotive applications. Heat resistant to temperatures up to 138°C/280°F for at least 45 minutes; after painting, it can be cleanly removed leaving a defined line with no adhesive residue.",
    "sizes": [
      "1mm x 55m",
      "2mm x 55m",
      "3mm x 55m",
      "6mm x 55m"
    ],
    "packSizes": [
      "1mm x 55m",
      "2mm x 55m",
      "3mm x 55m",
      "6mm x 55m"
    ],
    "hasOptions": true,
    "stockCode": "TPOR1",
    "barcode": "5060733583244",
    "priceRetailGbp": 2.91,
    "priceRetailEur": 3.4,
    "priceRrpExVat": 2.91,
    "priceRrpIncVat": 3.49,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "1mm x 55m",
        "stockCode": "TPOR1",
        "barcode": "5060733583244",
        "priceGbp": 2.91,
        "priceEur": 3.4,
        "priceRetailGbp": 2.91,
        "priceRetailEur": 3.4,
        "priceRrpExVat": 2.91,
        "priceRrpIncVat": 3.49,
        "sku": "TPOR1"
      },
      {
        "packSize": "2mm x 55m",
        "stockCode": "TPOR2",
        "barcode": "5060733583251",
        "priceGbp": 3.33,
        "priceEur": 3.9,
        "priceRetailGbp": 3.33,
        "priceRetailEur": 3.9,
        "priceRrpExVat": 3.33,
        "priceRrpIncVat": 3.99,
        "sku": "TPOR2"
      },
      {
        "packSize": "3mm x 55m",
        "stockCode": "TPOR3",
        "barcode": "5060733583268",
        "priceGbp": 3.74,
        "priceEur": 4.38,
        "priceRetailGbp": 3.74,
        "priceRetailEur": 4.38,
        "priceRrpExVat": 3.74,
        "priceRrpIncVat": 4.49,
        "sku": "TPOR3"
      },
      {
        "packSize": "6mm x 55m",
        "stockCode": "TPOR6",
        "barcode": "5060733583275",
        "priceGbp": 4.16,
        "priceEur": 4.87,
        "priceRetailGbp": 4.16,
        "priceRetailEur": 4.87,
        "priceRrpExVat": 4.16,
        "priceRrpIncVat": 4.99,
        "sku": "TPOR6"
      }
    ],
    "tapeWidths": [
      "1mm x 55m",
      "2mm x 55m",
      "3mm x 55m",
      "6mm x 55m"
    ],
    "hasTapeOptions": true,
    "tapePriceMatrix": [
      {
        "width": "1mm x 55m",
        "priceGbp": 2.91,
        "priceEur": 3.42,
        "priceRrpIncVat": 3.49,
        "stockCode": "TPOR1",
        "sku": "TPOR1",
        "barcode": "5060733583244"
      },
      {
        "width": "2mm x 55m",
        "priceGbp": 3.33,
        "priceEur": 3.92,
        "priceRrpIncVat": 3.99,
        "stockCode": "TPOR2",
        "sku": "TPOR2",
        "barcode": "5060733583251"
      },
      {
        "width": "3mm x 55m",
        "priceGbp": 3.74,
        "priceEur": 4.4,
        "priceRrpIncVat": 4.49,
        "stockCode": "TPOR3",
        "sku": "TPOR3",
        "barcode": "5060733583268"
      },
      {
        "width": "6mm x 55m",
        "priceGbp": 4.16,
        "priceEur": 4.89,
        "priceRrpIncVat": 4.99,
        "stockCode": "TPOR6",
        "sku": "TPOR6",
        "barcode": "5060733583275"
      }
    ]
  },
  {
    "id": "fk-2361",
    "brand": "Flake King",
    "category": "Masking Products",
    "name": "Prime Green Fine Line Mixed Set",
    "sku": "TPGRMix",
    "priceGbp": 15.83,
    "priceEur": 18.52,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FINE LINE PRO",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/WebGreenProSet.jpg?fit=600%2C600&ssl=1",
    "description": "Prime Green Fine Line Mixed Set\nSizes included: 1 x 1mm, 1 x 2mm, 2 x 3mm\nOur Prime Green Fine Line Tape uses thermally stabilised PVC backing with a rubber based pressure sensitive adhesive. Thinner and more translucent than other Fine Line Tapes making it ideal for seeing through to painted surfaces. Like our prime orange fine line it is extremely versatile, perfect for intricate, delicate and multi-layer masking perfect for undulating surfaces and capable of tight radius curves. Developed for high end industrial, commercial model makers, scenery, film and automotive applications. Heat resistant to temperatures up to 132° C/270° F for at least 30 minutes.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "stockCode": "TPGRMix",
    "barcode": "5060733583237",
    "priceRetailGbp": 15.83,
    "priceRetailEur": 18.52,
    "priceRrpExVat": 15.83,
    "priceRrpIncVat": 18.99
  },
  {
    "id": "fk-2352",
    "brand": "Flake King",
    "category": "Masking Products",
    "name": "Prime Green Fine Line Tape",
    "sku": "prime-green-fine-line-tape",
    "priceGbp": 2.91,
    "priceEur": 3.42,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FINE LINE PRO",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/Green1mm.png?fit=600%2C600&ssl=1",
    "description": "Available in 1mm, 2mm, 3mm & 6mm widths\nOur Prime Green Fine Line Tape uses thermally stabilised PVC backing with a rubber based pressure sensitive adhesive. Thinner and more translucent than other Fine Line Tapes making it ideal for seeing through to painted surfaces. Like our prime orange fine line it is extremely versatile, perfect for intricate, delicate and multi-layer masking perfect for undulating surfaces and capable of tight radius curves. Developed for high end industrial, commercial model makers, scenery, film and automotive applications. Heat resistant to temperatures up to 132° C/270° F for at least 30 minutes.",
    "sizes": [
      "1mm x 55m",
      "2mm x 55m",
      "3mm x 55m",
      "6mm x 55m"
    ],
    "packSizes": [
      "1mm x 55m",
      "2mm x 55m",
      "3mm x 55m",
      "6mm x 55m"
    ],
    "hasOptions": true,
    "tapeWidths": [
      "1mm x 55m",
      "2mm x 55m",
      "3mm x 55m",
      "6mm x 55m"
    ],
    "tapePriceMatrix": [
      {
        "width": "1mm x 55m",
        "priceGbp": 2.91,
        "priceEur": 3.42,
        "priceRrpIncVat": 3.49,
        "stockCode": "TPGR1",
        "sku": "TPGR1",
        "barcode": "5060733583190"
      },
      {
        "width": "2mm x 55m",
        "priceGbp": 3.33,
        "priceEur": 3.92,
        "priceRrpIncVat": 3.99,
        "stockCode": "TPGR2",
        "sku": "TPGR2",
        "barcode": "5060733583206"
      },
      {
        "width": "3mm x 55m",
        "priceGbp": 3.74,
        "priceEur": 4.4,
        "priceRrpIncVat": 4.49,
        "stockCode": "TPGR3",
        "sku": "TPGR3",
        "barcode": "5060733583213"
      },
      {
        "width": "6mm x 55m",
        "priceGbp": 4.16,
        "priceEur": 4.89,
        "priceRrpIncVat": 4.99,
        "stockCode": "TPGR6",
        "sku": "TPGR6",
        "barcode": "5060733583220"
      }
    ],
    "hasTapeOptions": true,
    "stockCode": "TPGR1",
    "barcode": "5060733583190",
    "priceRetailGbp": 2.91,
    "priceRetailEur": 3.4,
    "priceRrpExVat": 2.91,
    "priceRrpIncVat": 3.49,
    "hasPackPriceMatrix": true,
    "packPriceMatrix": [
      {
        "packSize": "1mm x 55m",
        "stockCode": "TPGR1",
        "barcode": "5060733583190",
        "priceGbp": 2.91,
        "priceEur": 3.4,
        "priceRetailGbp": 2.91,
        "priceRetailEur": 3.4,
        "priceRrpExVat": 2.91,
        "priceRrpIncVat": 3.49,
        "sku": "TPGR1"
      },
      {
        "packSize": "2mm x 55m",
        "stockCode": "TPGR2",
        "barcode": "5060733583206",
        "priceGbp": 3.33,
        "priceEur": 3.9,
        "priceRetailGbp": 3.33,
        "priceRetailEur": 3.9,
        "priceRrpExVat": 3.33,
        "priceRrpIncVat": 3.99,
        "sku": "TPGR2"
      },
      {
        "packSize": "3mm x 55m",
        "stockCode": "TPGR3",
        "barcode": "5060733583213",
        "priceGbp": 3.74,
        "priceEur": 4.38,
        "priceRetailGbp": 3.74,
        "priceRetailEur": 4.38,
        "priceRrpExVat": 3.74,
        "priceRrpIncVat": 4.49,
        "sku": "TPGR3"
      },
      {
        "packSize": "6mm x 55m",
        "stockCode": "TPGR6",
        "barcode": "5060733583220",
        "priceGbp": 4.16,
        "priceEur": 4.87,
        "priceRetailGbp": 4.16,
        "priceRetailEur": 4.87,
        "priceRrpExVat": 4.16,
        "priceRrpIncVat": 4.99,
        "sku": "TPGR6"
      }
    ]
  },
  {
    "id": "fk-2341",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Black Asteroid Metal Flake",
    "sku": "kromatic-asteroid-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2341.jpg",
    "description": "FKK13 Kromatic Asteroid Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1320030",
        "barcode": "5060733582957",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1320030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK13200100",
        "barcode": "5060733582964",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK13200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK132001000",
        "barcode": "5060733582971",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK132001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1337530",
        "barcode": "5060733582988",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1337530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK13375100",
        "barcode": "5060733582995",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK13375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK133751000",
        "barcode": "5060733583008",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK133751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2341.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2341.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2330",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Gun Metal Metal Flake",
    "sku": "gun-metal-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2330.jpg",
    "description": "FKS23 Gun Metal Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .008\"",
      "Large .015\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .008\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS2320030",
        "barcode": "5060733582117",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS2320030"
      },
      {
        "flakeSize": "Medium .008\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS23200100",
        "barcode": "5060733582124",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS23200100"
      },
      {
        "flakeSize": "Medium .008\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS232001000",
        "barcode": "5060733582131",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS232001000"
      },
      {
        "flakeSize": "Large .015\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS2337530",
        "barcode": "5060733582148",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS2337530"
      },
      {
        "flakeSize": "Large .015\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS23375100",
        "barcode": "5060733582155",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS23375100"
      },
      {
        "flakeSize": "Large .015\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS233751000",
        "barcode": "5060733582162",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS233751000"
      }
    ],
    "hasFullMatrix": true,
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2330.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ],
    "imageWebp": "assets/images/flakes/fk-2330.webp",
    "stockCode": "FKS23"
  },
  {
    "id": "fk-2319",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Elvis Gold Metal Flake",
    "sku": "kromatic-elvis-gold-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2319.jpg",
    "description": "FKK01 Kromatic Elvis Gold Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0220030",
        "barcode": "5060733582537",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0220030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK02200100",
        "barcode": "5060733582544",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK02200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK022001000",
        "barcode": "5060733582551",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK022001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0237530",
        "barcode": "5060733582568",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0237530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK02375100",
        "barcode": "5060733582575",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK02375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK023751000",
        "barcode": "5060733582582",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK023751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2319.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2319.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2308",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Dragon Koi Flake",
    "sku": "dragon-koi-flake",
    "priceGbp": 5.41,
    "priceEur": 6.33,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2308.jpg",
    "description": "FKI02 Dragon Koi Flake. Available in .008″ & .015″\nDue to the chemical nature of this flake it is only suitable for Dry Application using solvent or water based adhesion coat it cannot be suspended in a solvent.Due to the chemical nature of this flake it is only suitable for Dry Application using solvent or water based adhesion coat it cannot be suspended in a solvent.\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 137.49,
        "priceEur": 160.86,
        "priceRetailGbp": 137.49,
        "priceRetailEur": 160.86,
        "priceRrpExVat": 137.49,
        "priceRrpIncVat": 164.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 16.66,
        "priceEur": 19.49,
        "priceRetailGbp": 16.66,
        "priceRetailEur": 19.49,
        "priceRrpExVat": 16.66,
        "priceRrpIncVat": 19.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.41,
        "priceEur": 6.33,
        "priceRetailGbp": 5.41,
        "priceRetailEur": 6.33,
        "priceRrpExVat": 5.41,
        "priceRrpIncVat": 6.49
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.41,
        "priceEur": 6.33,
        "stockCode": "FKI0220030",
        "barcode": "5060733583077",
        "priceRetailGbp": 5.41,
        "priceRetailEur": 6.33,
        "priceRrpExVat": 5.41,
        "priceRrpIncVat": 6.49,
        "sku": "FKI0220030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 16.66,
        "priceEur": 19.49,
        "stockCode": "FKI02200100",
        "barcode": "5060733583084",
        "priceRetailGbp": 16.66,
        "priceRetailEur": 19.49,
        "priceRrpExVat": 16.66,
        "priceRrpIncVat": 19.99,
        "sku": "FKI02200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 137.49,
        "priceEur": 160.86,
        "stockCode": "FKI022001000",
        "barcode": "5060733583091",
        "priceRetailGbp": 137.49,
        "priceRetailEur": 160.86,
        "priceRrpExVat": 137.49,
        "priceRrpIncVat": 164.99,
        "sku": "FKI022001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.41,
        "priceEur": 6.33,
        "stockCode": "FKI0237530",
        "barcode": "5060733583107",
        "priceRetailGbp": 5.41,
        "priceRetailEur": 6.33,
        "priceRrpExVat": 5.41,
        "priceRrpIncVat": 6.49,
        "sku": "FKI0237530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 16.66,
        "priceEur": 19.49,
        "stockCode": "FKI02375100",
        "barcode": "5060733583114",
        "priceRetailGbp": 16.66,
        "priceRetailEur": 19.49,
        "priceRrpExVat": 16.66,
        "priceRrpIncVat": 19.99,
        "sku": "FKI02375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 137.49,
        "priceEur": 160.86,
        "stockCode": "FKI023751000",
        "barcode": "5060733583121",
        "priceRetailGbp": 137.49,
        "priceRetailEur": 160.86,
        "priceRrpExVat": 137.49,
        "priceRrpIncVat": 164.99,
        "sku": "FKI023751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2308.webp",
    "priceRetailGbp": 5.41,
    "priceRetailEur": 6.33,
    "priceRrpExVat": 5.41,
    "images": [
      "assets/images/flakes/fk-2308.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2297",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Water Dragon Flake",
    "sku": "water-dragon-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2297.jpg",
    "description": "FKI01 Water Dragon Flake. Available in .008″ & .015″\nDue to the chemical nature of this flake it is only suitable for Dry Application using solvent or water based adhesion coat it cannot be suspended in a solvent.\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKI0120030",
        "barcode": "5060733583015",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKI0120030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKI01200100",
        "barcode": "5060733583022",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKI01200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKI012001000",
        "barcode": "5060733583039",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKI012001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKI0137530",
        "barcode": "5060733583046",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKI0137530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKI01375100",
        "barcode": "5060733583053",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKI01375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKI013751000",
        "barcode": "5060733583060",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKI013751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2297.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2297.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2283",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Cobalt Blue Metal Flake",
    "sku": "candy-cobalt-blue-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2283.jpg",
    "description": "FKS20 Candy Cobalt Blue Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS2010030",
        "barcode": "5060733581936",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS2010030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS20100100",
        "barcode": "5060733581943",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS20100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS201001000",
        "barcode": "5060733581950",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS201001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS2020030",
        "barcode": "5060733581967",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS2020030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS20200100",
        "barcode": "5060733581974",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS20200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS202001000",
        "barcode": "5060733581981",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS202001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS2037530",
        "barcode": "5060733581998",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS2037530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS20375100",
        "barcode": "5060733582001",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS20375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS203751000",
        "barcode": "5060733582018",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS203751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2283.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2283.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2269",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Turquoise Blue Metal Flake",
    "sku": "candy-turquoise-blue-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2269.jpg",
    "description": "FKS21 Candy Turquoise Blue Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS2110030",
        "barcode": "5060733582025",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS2110030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS21100100",
        "barcode": "5060733582032",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS21100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS211001000",
        "barcode": "5060733582049",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS211001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS2120030",
        "barcode": "5060733582056",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS2120030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS21200100",
        "barcode": "5060733582063",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS21200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS212001000",
        "barcode": "5060733582070",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS212001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS2137530",
        "barcode": "5060733582087",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS2137530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS21375100",
        "barcode": "5060733582094",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS21375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS213751000",
        "barcode": "5060733582100",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS213751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2269.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2269.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2255",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Azura Blue Metal Flake",
    "sku": "candy-azura-blue-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2255.jpg",
    "description": "FKS19 Candy Azura Blue Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS1910030",
        "barcode": "5060733581844",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS1910030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS19100100",
        "barcode": "5060733581851",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS19100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS191001000",
        "barcode": "5060733581868",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS191001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1920030",
        "barcode": "5060733581875",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1920030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS19200100",
        "barcode": "5060733581882",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS19200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS192001000",
        "barcode": "5060733581899",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS192001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1937530",
        "barcode": "5060733581905",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1937530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS19375100",
        "barcode": "5060733581912",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS19375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS193751000",
        "barcode": "5060733581929",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS193751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2255.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2255.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2244",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Blue Flake",
    "sku": "kromatic-blue-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2244.jpg",
    "description": "FKK10 Kromatic Blue Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1020030",
        "barcode": "5060733582773",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1020030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK10200100",
        "barcode": "5060733582780",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK10200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK102001000",
        "barcode": "5060733582797",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK102001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1037530",
        "barcode": "5060733582803",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1037530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK10375100",
        "barcode": "5060733582810",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK10375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK103751000",
        "barcode": "5060733582827",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK103751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2244.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2244.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2233",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Light Blue Metal Flake",
    "sku": "candy-light-blue-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2233.jpg",
    "description": "FKS18 Candy Light Blue Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1820030",
        "barcode": "5060733581783",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1820030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS18200100",
        "barcode": "5060733581790",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS18200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS182001000",
        "barcode": "5060733581806",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS182001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1837530",
        "barcode": "5060733581813",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1837530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS18375100",
        "barcode": "5060733581820",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS18375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS183751000",
        "barcode": "5060733581837",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS183751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2233.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2233.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2222",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Poison Green Metal Flake",
    "sku": "kromatic-poison-green-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2222.jpg",
    "description": "FKK12 Kromatic Poison Green Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1220030",
        "barcode": "5060733582896",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1220030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK12200100",
        "barcode": "5060733582902",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK12200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK122001000",
        "barcode": "5060733582919",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK122001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1237530",
        "barcode": "5060733582926",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1237530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK12375100",
        "barcode": "5060733582933",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK12375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK123751000",
        "barcode": "5060733582940",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK123751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2222.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2222.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2208",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Emerald Green Metal Flake",
    "sku": "candy-emerald-green-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2208.jpg",
    "description": "FKS17 Candy Emerald Green Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS1710030",
        "barcode": "5060733581691",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS1710030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS17100100",
        "barcode": "5060733581707",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS17100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS171001000",
        "barcode": "5060733581714",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS171001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1720030",
        "barcode": "5060733581721",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1720030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS17200100",
        "barcode": "5060733581738",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS17200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS172001000",
        "barcode": "5060733581745",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS172001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1737530",
        "barcode": "5060733581752",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1737530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS17375100",
        "barcode": "5060733581769",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS17375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS173751000",
        "barcode": "5060733581776",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS173751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2208.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2208.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2194",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Poison Green Metal Flake",
    "sku": "candy-poison-green-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2194.jpg",
    "description": "FKS16 Candy Poison Green Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS1610030",
        "barcode": "5060733581608",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS1610030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS16100100",
        "barcode": "5060733581615",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS16100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS161001000",
        "barcode": "5060733581622",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS161001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1620030",
        "barcode": "5060733581639",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1620030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS16200100",
        "barcode": "5060733581646",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS16200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS162001000",
        "barcode": "5060733581653",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS162001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1637530",
        "barcode": "5060733581660",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1637530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS16375100",
        "barcode": "5060733581677",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS16375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS163751000",
        "barcode": "5060733581684",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS163751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2194.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2194.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2183",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Lime Green Metal Flake",
    "sku": "candy-lime-green-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2183.jpg",
    "description": "FKS15 Candy Lime Green Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1520030",
        "barcode": "5060733581547",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1520030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS15200100",
        "barcode": "5060733581554",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS15200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS152001000",
        "barcode": "5060733581561",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS152001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1537530",
        "barcode": "5060733581578",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1537530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS15375100",
        "barcode": "5060733581585",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS15375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS153751000",
        "barcode": "5060733581592",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS153751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2183.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2183.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2172",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Peacock Metal Flake",
    "sku": "peacock-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2172.jpg",
    "description": "FKM24 Peacock Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2420030",
        "barcode": "5060733582292",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2420030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM24200100",
        "barcode": "5060733582308",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM24200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM242001000",
        "barcode": "5060733582315",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM242001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2437530",
        "barcode": "5060733582322",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2437530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM24375100",
        "barcode": "5060733582339",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM24375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM243751000",
        "barcode": "5060733582346",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM243751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2172.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2172.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2158",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Purple Heart Metal Flake",
    "sku": "candy-purple-heart-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2158.jpg",
    "description": "FKS14 Candy Purple Heart Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS1410030",
        "barcode": "5060733581455",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS1410030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS14100100",
        "barcode": "5060733581462",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS14100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS141001000",
        "barcode": "5060733581479",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS141001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1420030",
        "barcode": "5060733581486",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1420030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS14200100",
        "barcode": "5060733581493",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS14200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS142001000",
        "barcode": "5060733581509",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS142001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1437530",
        "barcode": "5060733581516",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1437530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS14375100",
        "barcode": "5060733581523",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS14375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS143751000",
        "barcode": "5060733581530",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS143751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2158.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2158.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2147",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Sky Purple Metal Flake",
    "sku": "sky-purple-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2147.jpg",
    "description": "FKM22 Sky Purple Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2220030",
        "barcode": "5060733582179",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2220030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM22200100",
        "barcode": "5060733582186",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM22200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM222001000",
        "barcode": "5060733582193",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM222001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2237530",
        "barcode": "5060733582209",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2237530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM22375100",
        "barcode": "5060733582216",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM22375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM223751000",
        "barcode": "5060733582223",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM223751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2147.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2147.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2133",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Fewsha Metal Flake",
    "sku": "candy-fewsha-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2133.jpg",
    "description": "FKS11 Candy Fewsha Metal Flake. Available in .004′, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS1110030",
        "barcode": "5060733581301",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS1110030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS11100100",
        "barcode": "5060733581318",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS11100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS111001000",
        "barcode": "5060733581325",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS111001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1120030",
        "barcode": "5060733581332",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1120030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS11200100",
        "barcode": "5060733581349",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS11200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS112001000",
        "barcode": "5060733581356",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS112001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1137530",
        "barcode": "5060733581363",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1137530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS11375100",
        "barcode": "5060733581370",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS11375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS113751000",
        "barcode": "5060733581387",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS113751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2133.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2133.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2122",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Lavender Metal Flake",
    "sku": "kromatic-lavender-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2122.jpg",
    "description": "FKK08 Kromatic Lavender Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0820030",
        "barcode": "5060733582711",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0820030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK08200100",
        "barcode": "5060733582728",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK08200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK082001000",
        "barcode": "5060733582735",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK082001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0837530",
        "barcode": "5060733582742",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0837530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK08375100",
        "barcode": "5060733582759",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK08375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK083751000",
        "barcode": "5060733582766",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK083751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2122.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2122.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2111",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Bubble Gum Metal Flake",
    "sku": "kromatic-bubble-gum-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2111.jpg",
    "description": "FKK11 Kromatic Bubble Gum Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1120030",
        "barcode": "5060733582834",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1120030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK11200100",
        "barcode": "5060733582841",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK11200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK112001000",
        "barcode": "5060733582858",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK112001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK1137530",
        "barcode": "5060733582865",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK1137530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK11375100",
        "barcode": "5060733582872",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK11375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK113751000",
        "barcode": "5060733582889",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK113751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2111.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2111.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2104",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Pink Metal Flake",
    "sku": "candy-pink-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2104.jpg",
    "description": "FKS12 Candy Pink Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1220030",
        "barcode": "5060733581394",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1220030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS12200100",
        "barcode": "5060733581400",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS12200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS122001000",
        "barcode": "5060733581417",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS122001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1237530",
        "barcode": "5060733581424",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1237530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS12375100",
        "barcode": "5060733581431",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS12375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS123751000",
        "barcode": "5060733581448",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS123751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2104.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2104.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2097",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Fire Purple Metal Flake",
    "sku": "fire-purple-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2097.jpg",
    "description": "FKM25 Fire Purple Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2520030",
        "barcode": "5060733582353",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2520030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM25200100",
        "barcode": "5060733582360",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM25200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM252001000",
        "barcode": "5060733582377",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM252001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2537530",
        "barcode": "5060733582384",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2537530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM25375100",
        "barcode": "5060733582391",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM25375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM253751000",
        "barcode": "5060733582407",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM253751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2097.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2097.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2090",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Volcano Red Metal Flake",
    "sku": "kromatic-volcano-red-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2090.jpg",
    "description": "FKK05 Kromatic Volcano Red Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0420030",
        "barcode": "5060733582650",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0420030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK04200100",
        "barcode": "5060733582667",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK04200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK042001000",
        "barcode": "5060733582674",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK042001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0437515",
        "barcode": "5060733582681",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0437515"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK04375100",
        "barcode": "5060733582698",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK04375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK043751000",
        "barcode": "5060733582704",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK043751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2090.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2090.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2080",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Bright Red Metal Flake",
    "sku": "candy-bright-red-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2080.jpg",
    "description": "FKS10 Candy Bright Red Metal Flake. Available in .004′, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS1010030",
        "barcode": "5060733581219",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS1010030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS10100100",
        "barcode": "5060733581226",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS10100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS101001000",
        "barcode": "5060733581233",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS101001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1020030",
        "barcode": "5060733581240",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1020030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS10200100",
        "barcode": "5060733581257",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS10200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS102001000",
        "barcode": "5060733581264",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS102001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS1037530",
        "barcode": "5060733581271",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS1037530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS10375100",
        "barcode": "5060733581288",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS10375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS103751000",
        "barcode": "5060733581295",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS103751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2080.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2080.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2070",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Apple Red Metal Flake",
    "sku": "candy-apple-red-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2070.jpg",
    "description": "FKS09 Candy Apple Red Metal Flake. Available in .004′, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS0910030",
        "barcode": "5060733581127",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS0910030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS09100100",
        "barcode": "5060733581134",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS09100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS091001000",
        "barcode": "5060733581141",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS091001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0920030",
        "barcode": "5060733581158",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0920030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS09200100",
        "barcode": "5060733581165",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS09200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS092001000",
        "barcode": "5060733581172",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS092001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0937530",
        "barcode": "5060733581189",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0937530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS09375100",
        "barcode": "5060733581196",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS09375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS093751000",
        "barcode": "5060733581202",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS093751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2070.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2070.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2060",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Tangy Orange Metal Flake",
    "sku": "candy-tangy-orange-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2060.jpg",
    "description": "FKS08 Candy Tangy Orange Metal Flake. Available in .004′, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS0810030",
        "barcode": "5060733581035",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS0810030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS08100100",
        "barcode": "5060733581042",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS08100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS081001000",
        "barcode": "5060733581059",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS081001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0820030",
        "barcode": "5060733581066",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0820030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS08200100",
        "barcode": "5060733581073",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS08200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS082001000",
        "barcode": "5060733581080",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS082001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0837530",
        "barcode": "5060733581097",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0837530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS08375100",
        "barcode": "5060733581103",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS08375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS083751000",
        "barcode": "5060733581110",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS083751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2060.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2060.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2053",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Fizzy Green Metal Flake",
    "sku": "fizzy-green-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2053.jpg",
    "description": "FKM23 Fizzy Green Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2320030",
        "barcode": "5060733582230",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2320030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM23200100",
        "barcode": "5060733582247",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM23200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM232001000",
        "barcode": "5060733582254",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM232001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKM2337530",
        "barcode": "5060733582261",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKM2337530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKM23375100",
        "barcode": "5060733582278",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKM23375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKM233751000",
        "barcode": "5060733582285",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKM233751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2053.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2053.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2043",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Extreme Yellow Metal Flake",
    "sku": "candy-extreme-yellow-metal-flake",
    "priceGbp": 4.7,
    "priceEur": 5.5,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2043.jpg",
    "description": "FKS07 Candy Extreme Yellow Metal Flake. Available in .004′, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS0710030",
        "barcode": "5060733580946",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS0710030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS07100100",
        "barcode": "5060733580953",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS07100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS071001000",
        "barcode": "5060733580960",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS071001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0720030",
        "barcode": "5060733580977",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0720030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS07200100",
        "barcode": "5060733580984",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS07200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS072001000",
        "barcode": "5060733580991",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS072001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.7,
        "priceEur": 5.5,
        "stockCode": "FKS0737530",
        "barcode": "5060733580004",
        "priceRetailGbp": 4.7,
        "priceRetailEur": 5.5,
        "priceRrpExVat": 4.7,
        "priceRrpIncVat": 5.64,
        "sku": "FKS0737530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS07375100",
        "barcode": "5060733581011",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS07375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS073751000",
        "barcode": "5060733581028",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS073751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2043.webp",
    "priceRetailGbp": 4.7,
    "priceRetailEur": 5.5,
    "priceRrpExVat": 4.7,
    "images": [
      "assets/images/flakes/fk-2043.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2036",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Nevada Sands Metal Flake",
    "sku": "nevada-sands-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2036.jpg",
    "description": "FKS06 Nevada Sands Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0620030",
        "barcode": "5060733580885",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0620030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS06200100",
        "barcode": "5060733580892",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS06200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS062001000",
        "barcode": "5060733580908",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS062001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0637530",
        "barcode": "5060733580915",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0637530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS06375100",
        "barcode": "5060733580922",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS06375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS063751000",
        "barcode": "5060733580939",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS063751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2036.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2036.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2029",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Kromatic Copper Head Metal Flake",
    "sku": "kromatic-copper-head-metal-flake",
    "priceGbp": 6.21,
    "priceEur": 7.27,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2029.jpg",
    "description": "FKK03 Kromatic Copper Head Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0320030",
        "barcode": "5060733582599",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0320030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK03200100",
        "barcode": "5060733582605",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK03200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK032001000",
        "barcode": "5060733582612",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK032001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 6.21,
        "priceEur": 7.27,
        "stockCode": "FKK0337530",
        "barcode": "5060733582629",
        "priceRetailGbp": 6.21,
        "priceRetailEur": 7.27,
        "priceRrpExVat": 6.21,
        "priceRrpIncVat": 7.45,
        "sku": "FKK0337530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 17.38,
        "priceEur": 20.33,
        "stockCode": "FKK03375100",
        "barcode": "5060733582636",
        "priceRetailGbp": 17.38,
        "priceRetailEur": 20.33,
        "priceRrpExVat": 17.38,
        "priceRrpIncVat": 20.85,
        "sku": "FKK03375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 151.9,
        "priceEur": 177.72,
        "stockCode": "FKK033751000",
        "barcode": "5060733582643",
        "priceRetailGbp": 151.9,
        "priceRetailEur": 177.72,
        "priceRrpExVat": 151.9,
        "priceRrpIncVat": 182.28,
        "sku": "FKK033751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2029.webp",
    "priceRetailGbp": 6.21,
    "priceRetailEur": 7.27,
    "priceRrpExVat": 6.21,
    "images": [
      "assets/images/flakes/fk-2029.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2022",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Copper Head Metal Flake",
    "sku": "candy-copper-head-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2022.jpg",
    "description": "FKS05 Candy Copper Head Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0520030",
        "barcode": "5060733580823",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0520030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS05200100",
        "barcode": "5060733580830",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS05200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS052001000",
        "barcode": "5060733580847",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS052001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0537530",
        "barcode": "5060733580854",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0537530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS05375100",
        "barcode": "5060733580861",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS05375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS053751000",
        "barcode": "5060733580878",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS053751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2022.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2022.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2015",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Righteous Gold Metal Flake",
    "sku": "candy-righteous-gold-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2015.jpg",
    "description": "FKS04 Candy Righteous Gold Metal Flake. Available in .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0420030",
        "barcode": "5060733580762",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0420030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS04200100",
        "barcode": "5060733580779",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS04200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS042001000",
        "barcode": "5060733580786",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS042001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0437530",
        "barcode": "5060733580793",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0437530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS04375100",
        "barcode": "5060733580809",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS04375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS043751000",
        "barcode": "5060733580816",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS043751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2015.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2015.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-2005",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Sovereign Gold Metal Flake",
    "sku": "candy-sovereign-gold-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-2005.jpg",
    "description": "FKS03 Sovereign Gold Metal Flake. Available in .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS0310030",
        "barcode": "5060733580670",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS0310030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS03100100",
        "barcode": "5060733580687",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS03100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS031001000",
        "barcode": "5060733580694",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS031001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0320030",
        "barcode": "5060733580700",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0320030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS03200100",
        "barcode": "5060733580717",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS03200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS032001000",
        "barcode": "5060733580724",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS032001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0337530",
        "barcode": "5060733580731",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0337530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS03375100",
        "barcode": "5060733580748",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS03375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS033751000",
        "barcode": "5060733580755",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS033751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-2005.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-2005.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-1992",
    "brand": "Flake King",
    "category": "Dry Metal Flake (Glitter)",
    "flakeType": "Single Colour",
    "name": "Candy Elvis Gold Metal Flake",
    "sku": "candy-elvis-gold-metal-flake",
    "priceGbp": 4.71,
    "priceEur": 5.51,
    "inStock": true,
    "isPreOrder": false,
    "badge": "FLAKE KING (SINGLE COLOUR)",
    "image": "assets/images/flakes/fk-1992.jpg",
    "description": "FKS02 Elvis Gold Metal Flake. Available in .002″, .004″, .008″ & .015″\nIf you are looking for pure commercial/industrial grade Glitters or Metal Flake that are specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine. All of which require metal flake glitter with outstanding physical and chemical properties…\nThen you have come to the right company!\nFlake King Polyester Flake was specifically designed to meet the requirements of manufacturers of decorated fabrics, adhesives, vinyl, sheeting, plastic molding, inks, paints, in industries such as automotive, leisure, commercial properties, theme parks, marine and many more, all of which require metal flake glitter with outstanding physical and chemical properties.\nA full chart of colours can be found in the images.\nTo learn more about the following products – guns, flake & surface binders please watch the video by clicking this link – Product Video",
    "sizes": [
      "Ultra Small .002\"",
      "Small .008\"",
      "Medium .015\"",
      "Large .025\""
    ],
    "packSizes": [
      "30g Jar (Gun Mount)",
      "100g Jar (Refill / Trade)",
      "1000g (1 Kilo Trade Pack)"
    ],
    "hasOptions": true,
    "packPriceMatrix": [
      {
        "packSize": "1000g (1 Kilo Trade Pack)",
        "priceGbp": 333.33,
        "priceEur": 390,
        "priceRetailGbp": 333.33,
        "priceRetailEur": 390,
        "priceRrpExVat": 333.33,
        "priceRrpIncVat": 399.99
      },
      {
        "packSize": "100g Jar (Refill / Trade)",
        "priceGbp": 33.63,
        "priceEur": 39.35,
        "priceRetailGbp": 33.63,
        "priceRetailEur": 39.35,
        "priceRrpExVat": 33.63,
        "priceRrpIncVat": 40.35
      },
      {
        "packSize": "30g Jar (Gun Mount)",
        "priceGbp": 11.08,
        "priceEur": 12.96,
        "priceRetailGbp": 11.08,
        "priceRetailEur": 12.96,
        "priceRrpExVat": 11.08,
        "priceRrpIncVat": 13.3
      }
    ],
    "hasPackPriceMatrix": true,
    "fullMatrixPricing": [
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 11.08,
        "priceEur": 12.96,
        "stockCode": "FKS025030",
        "barcode": "5060733580557",
        "priceRetailGbp": 11.08,
        "priceRetailEur": 12.96,
        "priceRrpExVat": 11.08,
        "priceRrpIncVat": 13.3,
        "sku": "FKS025030"
      },
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 33.63,
        "priceEur": 39.35,
        "stockCode": "FKS0250100",
        "barcode": "5060733580564",
        "priceRetailGbp": 33.63,
        "priceRetailEur": 39.35,
        "priceRrpExVat": 33.63,
        "priceRrpIncVat": 40.35,
        "sku": "FKS0250100"
      },
      {
        "flakeSize": "Ultra Small .002\"",
        "rawFlakeSize": "ultra-small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 333.33,
        "priceEur": 390,
        "stockCode": "FKS02501000",
        "barcode": "5060733580571",
        "priceRetailGbp": 333.33,
        "priceRetailEur": 390,
        "priceRrpExVat": 333.33,
        "priceRrpIncVat": 399.99,
        "sku": "FKS02501000"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 5.46,
        "priceEur": 6.39,
        "stockCode": "FKS0210030",
        "barcode": "5060733580588",
        "priceRetailGbp": 5.46,
        "priceRetailEur": 6.39,
        "priceRrpExVat": 5.46,
        "priceRrpIncVat": 6.55,
        "sku": "FKS0210030"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 14.88,
        "priceEur": 17.41,
        "stockCode": "FKS02100100",
        "barcode": "5060733580595",
        "priceRetailGbp": 14.88,
        "priceRetailEur": 17.41,
        "priceRrpExVat": 14.88,
        "priceRrpIncVat": 17.85,
        "sku": "FKS02100100"
      },
      {
        "flakeSize": "Small .008\"",
        "rawFlakeSize": "small",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 141.66,
        "priceEur": 165.74,
        "stockCode": "FKS021001000",
        "barcode": "5060733580601",
        "priceRetailGbp": 141.66,
        "priceRetailEur": 165.74,
        "priceRrpExVat": 141.66,
        "priceRrpIncVat": 169.99,
        "sku": "FKS021001000"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0220030",
        "barcode": "5060733580618",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0220030"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS02200100",
        "barcode": "5060733580625",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS02200100"
      },
      {
        "flakeSize": "Medium .015\"",
        "rawFlakeSize": "medium",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS022001000",
        "barcode": "5060733580632",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS022001000"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "30g Jar (Gun Mount)",
        "rawPackSize": "30g",
        "priceGbp": 4.71,
        "priceEur": 5.51,
        "stockCode": "FKS0237530",
        "barcode": "5060733580649",
        "priceRetailGbp": 4.71,
        "priceRetailEur": 5.51,
        "priceRrpExVat": 4.71,
        "priceRrpIncVat": 5.65,
        "sku": "FKS0237530"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "100g Jar (Refill / Trade)",
        "rawPackSize": "100g",
        "priceGbp": 12.49,
        "priceEur": 14.61,
        "stockCode": "FKS02375100",
        "barcode": "5060733580656",
        "priceRetailGbp": 12.49,
        "priceRetailEur": 14.61,
        "priceRrpExVat": 12.49,
        "priceRrpIncVat": 14.99,
        "sku": "FKS02375100"
      },
      {
        "flakeSize": "Large .025\"",
        "rawFlakeSize": "large",
        "packSize": "1000g (1 Kilo Trade Pack)",
        "rawPackSize": "1000g",
        "priceGbp": 108.33,
        "priceEur": 126.75,
        "stockCode": "FKS023751000",
        "barcode": "5060733580663",
        "priceRetailGbp": 108.33,
        "priceRetailEur": 126.75,
        "priceRrpExVat": 108.33,
        "priceRrpIncVat": 129.99,
        "sku": "FKS023751000"
      }
    ],
    "hasFullMatrix": true,
    "imageWebp": "assets/images/flakes/fk-1992.webp",
    "priceRetailGbp": 4.71,
    "priceRetailEur": 5.51,
    "priceRrpExVat": 4.71,
    "images": [
      "assets/images/flakes/fk-1992.jpg",
      "assets/images/flakes/flake_king_color_chart.png",
      "assets/images/flakes/flake_king_size_chart.png"
    ]
  },
  {
    "id": "fk-1972",
    "brand": "Flake King",
    "category": "Dry Metal Flake Guns",
    "name": "Flake King 1050 Dry Metal Flake Gun",
    "sku": "FOM1050",
    "priceGbp": 108.33,
    "priceEur": 126.75,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO GUN SYSTEM",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10501.png?fit=600%2C600&ssl=1",
    "description": "The Flake King 1050 is designed for heavy-duty dry powder and coarse metallic flake distribution. Machined from aircraft-grade billet aluminium with hard anodising, it features an enlarged internal pick-up tube engineered to spray larger flake grades and heavy powders smoothly at 10–20 PSI.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM1050",
    "barcode": "5060733583138",
    "priceRetailGbp": 108.33,
    "priceRetailEur": 126.75,
    "priceRrpExVat": 108.33,
    "priceRrpIncVat": 129.99,
    "images": [
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10501.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10502.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10503.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10504.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10505.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10506.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM10507.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM1050A.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM1050B.png?fit=600%2C600&ssl=1"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "How To Spray Metal Flake Using The Flake King 1000 / 1050 Dry Metal Flake Spray Gun",
        "creator": "Tony's Refinishing",
        "url": "https://www.youtube.com/watch?v=YmE-kCQLjvM",
        "embedId": "YmE-kCQLjvM",
        "duration": "8:42",
        "badge": "Master Tutorial"
      },
      {
        "platform": "youtube",
        "title": "How to metal flake with Flake King Guns.",
        "creator": "SM Designs Airbrush",
        "url": "https://www.youtube.com/watch?v=13SQPoGvjk8",
        "embedId": "13SQPoGvjk8",
        "duration": "12:15",
        "badge": "Pro Demonstration"
      }
    ],
    "summary": "Heavy-duty dry applicator gun engineered specifically for coarse metallic flakes, heavy metal blends, and specialty dry powders.",
    "benefits": [
      "Engineered for Heavy Flakes & Powders: Features an enlarged internal bore and CNC machined pick-up tube designed to handle heavy particles without restriction.",
      "Dual-Mode Barrel: 360° rotating nozzle with adjustable self-levelling or rigid barrel locking.",
      "Industrial Durability: Solid CNC billet aluminium body with hard anodised protective coating.",
      "Broad Industrial Versatility: Used for automotive flake, anti-slip coatings, and precision powder distribution."
    ],
    "howItWorks": [
      "Step 1 - Set Up: Connect to air supply at 10–20 PSI (minimum 2 CFM recommended).",
      "Step 2 - Apply Dry Flake: Spray dry heavy flake or powder over wet binder coat.",
      "Step 3 - Seal: Allow to flash, blow off excess, and seal with 2K clear."
    ],
    "inTheBox": [
      "Flake King 1050 Billet Gun Body",
      "Heavy Powder Pick-Up Tube Assembly",
      "Articulated Self-Levelling Barrel & 360° Rotating Tip",
      "1× 100g Flake Jar & 1/4\" BSP Fitting"
    ]
  },
  {
    "id": "fk-1970",
    "brand": "Flake King",
    "category": "Dry Metal Flake Guns",
    "name": "Flake King 550 Mini Dry Metal Flake Gun",
    "sku": "FOM550",
    "priceGbp": 99.99,
    "priceEur": 116.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "PRO GUN SYSTEM",
    "image": "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5501.png?fit=600%2C600&ssl=1",
    "description": "The Flake King 550 Mini is a scaled-down version of the 1000 gun engineered specifically to operate from studio airbrush compressors. Ideal for helmets, skateboards, bikes, and small automotive components. Allows you to apply wet clear with your airbrush and instantly apply dry flake with the 550 Mini without changing setups.",
    "sizes": [],
    "packSizes": [],
    "hasOptions": false,
    "hasFullMatrix": true,
    "stockCode": "FOM550",
    "barcode": "5060733580069",
    "priceRetailGbp": 99.99,
    "priceRetailEur": 116.99,
    "priceRrpExVat": 99.99,
    "priceRrpIncVat": 119.99,
    "images": [
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5501.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5502.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5503.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5504.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5505.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5506.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5507.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5508.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM5509.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM550A.png?fit=600%2C600&ssl=1",
      "https://i0.wp.com/www.flakeking.com/wp-content/uploads/2020/06/FOM550B.png?fit=600%2C600&ssl=1"
    ],
    "videos": [
      {
        "platform": "youtube",
        "title": "First Try Of The Flake King FOM550 Dry Flake Gun",
        "creator": "Bodganeering",
        "url": "https://www.youtube.com/watch?v=RRSWEgBVkmc",
        "embedId": "RRSWEgBVkmc",
        "duration": "10:14",
        "badge": "First Impressions"
      },
      {
        "platform": "youtube",
        "title": "How to metal flake with Flake King Guns.",
        "creator": "SM Designs Airbrush",
        "url": "https://www.youtube.com/watch?v=13SQPoGvjk8",
        "embedId": "13SQPoGvjk8",
        "duration": "12:15",
        "badge": "Pro Tutorial"
      }
    ],
    "summary": "Compact dry metal flake gun engineered to run on low-CFM airbrush compressors. Perfect for custom painters working on helmets, skateboards, bicycle frames, and small motorcycle parts.",
    "benefits": [
      "Low Air Consumption: Operates smoothly at 10–18 PSI on standard studio airbrush compressors (1/4\" to 1/8\" BSP adaptor included).",
      "Ergonomic Pistol Grip: Lightweight CNC aluminium body provides pinpoint maneuverability in tight curves and recesses.",
      "Consistent Fluidization: Internal Venturi agitator prevents flake pack-down and ensures uniform dry dispersion without spitting.",
      "Screw-In Jar Mount: Fits all standard 30g and 50g Flake King jars."
    ],
    "howItWorks": [
      "Step 1 - Wet Binder: Apply a wet intercoat clear or binder coat to the target area.",
      "Step 2 - Spray Dry Flake: Spray dry flake evenly at 10–15 PSI with the FK-550 Mini.",
      "Step 3 - Final Clear: Blow off excess dry flake and seal with topcoat clear."
    ],
    "inTheBox": [
      "Flake King 550 Mini Gun Body",
      "Precision Blending Nozzle",
      "1/4\" to 1/8\" BSP Air Line Adaptor",
      "1× 30g Flake Jar & Manual"
    ]
  },
  {
    "id": "va-635",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir Ice Hockey Goalie Mask Jig (VAX-JG-GLMSK)",
    "sku": "VAX-JG-GLMSK",
    "priceEur": 129.16,
    "priceGbp": 110.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/10/VAX-JG-GLMSK-Goalie-Mask-Jig-Render-1.jpg",
    "description": "VsionAir Ice Hockey Goalie Mask Jig\nThe jig allows you to adjust and lock the mask into any position making it extremely comfortable to work on. It also comes with a VFrame extension that enables you to apply a 2”/50mm washer to the inside of the rear head protection plate using either masking tape or hot glue and and then place it on a strong mounted Neodymium magnet to the position it would be on a persons head. Making it perfect for lining up artwork and graphics.\nThe perfect Jig for every aspect of painting from prep. base coating, flaking, clear coating and apply your pinstripe, leafing and art work suitable for airbrush, marker, and normal brushwork to every side including the top.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "videos": [
      {
        "platform": "youtube",
        "title": "VsionAir FK500 550 Gun Holder VAX 500 HLDR",
        "creator": "Flake King",
        "url": "https://www.youtube.com/watch?v=vrcLcQAKwvo",
        "embedId": "vrcLcQAKwvo",
        "duration": "2:10",
        "badge": "Rig Demo"
      }
    ],
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-627",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VAX Lighting, Camera & Dual Vertical Tool Bar Rig 1.5m (VAX-LCT-RIG-1500)",
    "sku": "VAX-LCT-RIG-1200-1",
    "priceEur": 168.47,
    "priceGbp": 143.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/1000mm_x_1200mm_Vertical_Tool_Bars__Lighting_Camera_Rig_Reworked.png",
    "description": "The VsioAir Lighting, Camera & Vertical Tool Bar Rig, is designed to provide you with the physical structure to mount lighting, cameras and any of our accessories directly to it. It bolts to the horizontal tool bar and with the use of the IABS Brackets enables you to angle the vertical bars from directly above to 90 degrees behind the work area. This is a real game changer to your work area – you’ll be amazed at what you can mount to this.\nIt mounts to both our Desk Mount Stand and our Tripod Stand (via our VsionAir Tool Bar). Available in 3 Widths 1m, 1.2m & 1.5m\nTo download the assembly instructions please click on link\nTo download the packing list please click on link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-494",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir tm Canvass Jig 1000mm Spine (VAX-JG-CNVSS-1000)",
    "sku": "VAX-JG-CNVSS-1500-1",
    "priceEur": 140.39,
    "priceGbp": 119.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-CNVSS-Canvass-Jig-Reworked.png",
    "description": "Our Canvass jigs are ideal for holding canvasses this jig can hold up to 900mm high.\nThe top & bottom VFrame acts as a toolbar mount as well.\nWe can special build Easels using our Canvass Jigs and Tri-Stands to create Easels that will hold a canvass of up to 2.5mm high by what ever width you require.\nTo download a copy of the assembly drawing please click here\nTo download a copy of the packing list please click here",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-463",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6W-KNB-M VsionAir M6 Wing Knob Male",
    "sku": "VAX-6W-KNB-M",
    "priceEur": 3.36,
    "priceGbp": 2.87,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6W-KNB-M-M6-Male-Wing-Knob-Render-Web.png",
    "description": "VAX-6W-KNB-M VsionAir M6 Wing Knob Male",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-462",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-10-WSHR VsionAir M10 Washer for Desk Mount",
    "sku": "VAX-10-WSHR",
    "priceEur": 0.28,
    "priceGbp": 0.24,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6WSHR-M6-Washer-Render-Web.png",
    "description": "VAX-10-WSHR VsionAir M10 Washer for Desk Mount",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-460",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-10-CB-100 VsionAir M10 x 100mm Coach Bolt for Desk Top Mount",
    "sku": "VAX-10-CB-100",
    "priceEur": 3.36,
    "priceGbp": 2.87,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-10-CB-100-M10-Coach-Bolt-Render-Web.png",
    "description": "VAX-10-CB-100 VsionAir M10 x 100mm Coach Bolt for Desk Top Mount",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-459",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-10STR-KNB-F VsionAir M10 Star Knob for Desk Mount",
    "sku": "VAX-10STR-KNB-F",
    "priceEur": 8.41,
    "priceGbp": 7.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6STR-KNB-F-Render-Web.png",
    "description": "VAX-10W-KNB-F VsionAir M10 Star Knob for Desk Mount Replacement Knob",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-458",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-620-CLMP VsionAir M6 Clamping Handle",
    "sku": "VAX-620-CLMP",
    "priceEur": 11.22,
    "priceGbp": 9.59,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-630-CLMP-M6-Clamp-Handle-Render-Web.png",
    "description": "VAX-620-CLMP VsionAir M6 Clamping Handle",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-454",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6W-KNB-F VsionAir M6 Wing Knob Female",
    "sku": "VAX-6W-KNB-F",
    "priceEur": 5.6,
    "priceGbp": 4.79,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6W-KNB-F-Web.png",
    "description": "VAX-6W-KNB-F VsionAir M6 Wing Knob Female",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-453",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6R-WASHR-10 VsionAir M6 Rubber Washer 10 Pack",
    "sku": "VAX-6R-WSHR-10",
    "priceEur": 6.31,
    "priceGbp": 5.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6WSHR-RBR-M6-Rubber-Washer-Render-Web.png",
    "description": "VAX-6R-WASHR-10 VsionAir M6 Rubber Washer 10 Pack",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-452",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6S-WASHR-10 VsionAir M6 Washer 10 Pack",
    "sku": "VAX-6s-WSHR",
    "priceEur": 0.83,
    "priceGbp": 0.71,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6WSHR-M6-Washer-Render-Web.png",
    "description": "VAX-6S-WASHR-10 VsionAir M6 Washer 10 Pack",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-451",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6Nyloc VsionAir M6 Nylon Lock Nut 10 Pack",
    "sku": "VAX-6Nyloc-10",
    "priceEur": 2.23,
    "priceGbp": 1.91,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6Nyloc-M6-Nyloc-Nut-Render-Web-1.png",
    "description": "VAX-6Nyloc VsionAir M6 Nylon Lock Nut. Pack of 10",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-450",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6HN-10 VsionAir M6 Half Nut 10 Pack",
    "sku": "VA-450",
    "priceEur": 0.84,
    "priceGbp": 0.72,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6HN-M6-Half-Nut-Render-Web.png",
    "description": "VAX-6HN-10 VsionAir M6 Half Nut 10 Pack, our standard nut for all Vframe mounts where the Flange Head Machine Screws are used.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-448",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6CSH-8-10 VsionAir M6 x 8mm Countersunk Pozi Head Machine Screw 10 Pack",
    "sku": "VA-448",
    "priceEur": 1.39,
    "priceGbp": 1.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Countersunk-MC-Screw-Render-Web.png",
    "description": "VAX-6CSH-8-10 VsionAir M6 x 8mm Countersunk Pozi Head Machine Screw 10 Pack Used in our Height Adjuster",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-447",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6H-60-10  VsionAir M6 x 60mm Hex Head Machine Screw, 10 Pack",
    "sku": "VAX-6H-60-10",
    "priceEur": 2.53,
    "priceGbp": 2.16,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Hex-Head-Bolt-Render-Web.png",
    "description": "VAX-6H-60-10 VsionAir M6 x 60mm Hex Head Machine Screw, 10 Pack",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-446",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6H-35-10  VsionAir M6 x 35mm Hex Head Machine Screw, 10 Pack",
    "sku": "VAX-6H-35-10",
    "priceEur": 1.39,
    "priceGbp": 1.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Hex-Head-Bolt-Render-Web.png",
    "description": "VAX-6H-35-10 VsionAir M6 x 35mm Hex Head Machine Screw, 10 Pack",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-445",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6H-16-10  VsionAir M6 x 16mm Hex Head Machine Screw, 10 Pack",
    "sku": "VAX-6H-16-10",
    "priceEur": 1.39,
    "priceGbp": 1.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Hex-Head-Bolt-Render-Web.png",
    "description": "VAX-6H-16-10 VsionAir M6 x 16mm Hex Head Machine Screw, 10 Pack",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-444",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6FH-12-10 VsionAir M6 x 12mm Flange Head Machine Screw Pack of 10",
    "sku": "VAX-6FH-10-10-1",
    "priceEur": 3.37,
    "priceGbp": 2.88,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Flange-Head-Machine-Screw-Render-Web.png",
    "description": "VAX-6FH-12-10 VsionAir M6 x 8mm Flange Head Machine Screw.\nPack of 10",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-443",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6FH-10-10 VsionAir M6 x 10mm Flange Head Machine Screw Pack of 10",
    "sku": "VAX-6FH-10-10",
    "priceEur": 3.37,
    "priceGbp": 2.88,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Flange-Head-Machine-Screw-Render-Web.png",
    "description": "VAX-6FH-10-10 VsionAir M6 x 8mm Flange Head Machine Screw.\nPack of 10",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-442",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-6FH-8-10 VsionAir M6 x 8mm Flange Head Machine Screw Pack of 10",
    "sku": "VAX-6FH-8-10",
    "priceEur": 3.37,
    "priceGbp": 2.88,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Flange-Head-Machine-Screw-Render-Web.png",
    "description": "VAX-6FH-8-10 VsionAir M6 x 8mm Flange Head Machine Screw.\nPack of 10",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-440",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-4Nyloc VsionAir M4 Nylon Lock Nut",
    "sku": "VAX-4Nyloc-10",
    "priceEur": 2.23,
    "priceGbp": 1.91,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-6Nyloc-M6-Nyloc-Nut-Render-Web-1.png",
    "description": "VAX-4Nyloc VsionAir M4 Nylon Lock Nut. Pack of 10",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-439",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-4-FH-8 VsionAir M4 x 8mm Flange Head Machine Screw",
    "sku": "VAX-4FH-8-10",
    "priceEur": 1.39,
    "priceGbp": 1.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/Flange-Head-Machine-Screw-Render-Web.png",
    "description": "VAX-4-FH-8 VsionAir M4 x 8mm Flange Head Machine Screw – typically used for mounting “Clipboard Clip” to Universal Mount Holder.\nPack of 10",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-438",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-END-STP VsionAir End Stop Bracket",
    "sku": "VAX-END-STP",
    "priceEur": 4.2,
    "priceGbp": 3.59,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-END-STP-Render-Web.png",
    "description": "VAX-END-STP VsionAir End Stop Bracket this little bracket has many applications.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-437",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-50-BRKT 50mm x 90 Degree Bracket",
    "sku": "VAX-50-BRKT",
    "priceEur": 7.01,
    "priceGbp": 5.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-5090-Render-Web.png",
    "description": "VAX-50-BRKT 50mm x 90 Degree Bracket used in many jigs and assemblies.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-436",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-25-BRKT 25mm x 90 Degree Bracket",
    "sku": "VAX-25-BRKT",
    "priceEur": 5.6,
    "priceGbp": 4.79,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-2590-Render-Web.png",
    "description": "VAX-25-BRKT 25mm x 90 Degree Bracket used in many jigs and assemblies.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-435",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-IAB-BRKT VsionAir IABS Bracket",
    "sku": "VAX-IABS-BRKT",
    "priceEur": 8.41,
    "priceGbp": 7.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/IABS-Bracket-Render-Web.png",
    "description": "VAX-IAB-BRKT VsionAir IABS Bracket is used with all our (IABS) Independent Airbrush Stations and Jig.\nAnother versatile bracket that we’re sure you’ll find many uses for.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-434",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "VAX-VBRKT VsionAir V Bracket",
    "sku": "VAX-VBRKT",
    "priceEur": 6.31,
    "priceGbp": 5.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-V-BRKT-Web-Render.png",
    "description": "Our V Bracket is one of the most versatile brackets that we have designed. it is used in many of our jigs and assemblies.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-353",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Multi Function Holder (VAX-TM-M-SS)",
    "sku": "VAX-TM-M-SS",
    "priceEur": 30.88,
    "priceGbp": 26.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-T-M-SS-Spamrt-Speaker-Render-Reworked.png",
    "description": "https://youtu.be/szjxjaqZPlk\nWe know that keeping hydrated and relaxed helps the creative juices flowing. So again we’ve thought about how we can help with that.   \nWe designed a universal mount that holds smart speakers, mugs (not fancy china cups!) and thermal mugs. We’re sure you’ll find other uses for them, when you do, please let us know.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-351",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Bottle & Airbrush Mount Holder (VAX-TS-ABP-HLDR)",
    "sku": "VAX-S-ABP-HLDR",
    "priceEur": 28.07,
    "priceGbp": 23.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-TS-ABP-HLDR_T_Shirt_Airbrush_n_Paint_Bottle_Holder_Assembly_Render-Reworked.png",
    "description": "This little beauty was designed as a request by David Monnig especially for T Shirt Artists that have a need to have an array of pre loaded brushes enabling you to just pick them up and use them. Suitable for the 4oz. Createx bottles.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-349",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsiobAir 80mm Pot Organiser (VAX-POT1)",
    "sku": "VAX-POT1",
    "priceEur": 14.03,
    "priceGbp": 11.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/AB-POT-Render-Reworked.png",
    "description": "https://youtu.be/uEGzpP0pawY\nA handy little pot 60mm square x 85mm deep ideal for storing your knives, scalpels and small paint brushes. supplied with 3D Printed Rubber top, mounting bolt, nut & rubber washer.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-347",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Flake King Gravity Spray Gun Holder (VAX-SPRYGN-HLDR)",
    "sku": "VAX-SPRYGN-HLDR-1-1",
    "priceEur": 16.84,
    "priceGbp": 14.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-SPRYGUN-HLDR-Spray-Gun-Render-Reworked.png",
    "description": "https://youtu.be/EAfa4Os2IzA\nGravity Feed Spray Gun Holder mount anywhere horizontally on our VsionFrame TM– great for in the booth when swapping between applying binders and flake.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-345",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Flake King 1000 Holder (VAX-1000-HLDR)",
    "sku": "VAX-1000-HLDR-1",
    "priceEur": 16.84,
    "priceGbp": 14.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-1000-Holder-Render-Reworked.png",
    "description": "https://youtu.be/lZvRDf-DNyU\nFlake King 1000/1050 Holder mount anywhere horizontally on our VsionFrame TM– great for in the booth when swapping between applying binders and flake.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-343",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Flake King 500 Holder (VAX-500-HLDR)",
    "sku": "VAX-500-HLDR",
    "priceEur": 14.03,
    "priceGbp": 11.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-500-HLDR-F0M500-Holder-Render-Reworked.png",
    "description": "https://youtu.be/vrcLcQAKwvo\nFlake King 500/550 Holder mount anywhere horizontally on our VsionFrame TM– great for in the booth when swapping between applying binders and flake.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-341",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Hook (VAX-HOOK)",
    "sku": "VAX-HOOK",
    "priceEur": 8.41,
    "priceGbp": 7.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-HOOK-40mm-Hook-Render-reworked.png",
    "description": "A simple 40mm hook that you can fix anywhere on our VsionFrameTM – great for hanging anything from a spray gun, to masking tape, stencils or even your hat!",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-339",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Paint Bottle Holder (VAX-PNT-HLDR)",
    "sku": "VAX-PNT-HLDR",
    "priceEur": 28.07,
    "priceGbp": 23.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-PNT-HLDR-Paint-Bottle-Holder-Render-Reworked.png",
    "description": "https://youtu.be/_-nhoKstnBM\nhttps://youtu.be/_-nhoKstnBM\nPaint Bottle Holder (VAX-PNT-HLDR) – Another quirky but handy little holder, mount it anywhere – it holds up to 6 bottles of paint from small square bottles of 30mm to large 4oz Createx bottles. They also bolt together for infinite storage.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-336",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Reference & Spray Out Holder (VAX-REF)",
    "sku": "VAx-REF",
    "priceEur": 37.9,
    "priceGbp": 32.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-REF-Digital-Reference-Holder-Render-reworked.png",
    "description": "https://youtu.be/g6bL1qAWi0w\nThis multi-purpose accessory made from powder coated steel can be used in different ways for different uses. Here are a few examples;\n1. It will hold a digital device perfect for reference or watching online Airbrush Courses, enabling you follow like for like.\n2. It can hold printed reference, simply set it at your most comfortable height. 3. It can hold plain paper, great for testing your paint is the right colour and the viscosity correct – you know the drill!\n4. Use it to hold your stencils on – dont they always fall on the floor or you can’t find them.\nYou can configure to fasten right or left handed and comes with both digital brackets & sprung clipboard.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-328",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "Vsionair tm Sparmax Regulator & Airline Holder (VAX-REG)",
    "sku": "VAX-REG",
    "priceEur": 11.22,
    "priceGbp": 9.59,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/Regulator_Holder_Assembly.png",
    "description": "https://youtu.be/pTiOy6g3lwY\nDo you use a quick release and swap between your airbrushes? Well this neat little mounting bracket holds both a Sparmax Pressure Regulator and airline holder – no more chasing it around the floor.\nIt’s the little details that make the difference.\nSupplied with mounting nuts & bolts.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-326",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Pressure Cleaning Pot & Holder (VAX-APCS)",
    "sku": "VA-326",
    "priceEur": 23.86,
    "priceGbp": 20.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-APCS-Air-Pressure-Cleaning-Pot-Render-Reworked.png",
    "description": "https://youtu.be/_FdJSHCTCfE\nSometimes using a small bottle of airbrush cleaner just doesn’t cut it, Our 250ml squeeze bottle with small aperture spout enables to put some pressure and volume in there. It is supplied with its own mount so you can keep it to hand.\nCustomers are also using them to hold the reducers/thinners they’re suitable for both water based & solvents products.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-324",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Universal Cleaning Pot Holder (VAX-IWUSOP)",
    "sku": "VAX-IWUSOP",
    "priceEur": 28.07,
    "priceGbp": 23.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-IWUSOP-Iwata-Spray-Out-Pot-Holder-Render-Reworked.png",
    "description": "Have your spray-out pot close to hand using our great little holder. Stops you from knocking it off the bench.\nIt really helps when you can find your equipment easy, when everything is mounted correctly it makes life so much easier enabling to concentrate on your art.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-323",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Airbrush Holder Frame 300mm (VAX-ABHF-300)",
    "sku": "VAX-ABHF-300",
    "priceEur": 9.82,
    "priceGbp": 8.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-ABH-6-Airbrush-Holder-Assembly-Render-Reworked.png",
    "description": "https://youtu.be/SIJMAgx7J6c\nMount them vertically or horizontally to our Frame tm available in different lengths dependent upon how many airbrushes you want to hold. Comes with a pre screwed bolted and rubberised mount for easy fix. Illustration shows a fully loaded version.\nPlease note that you will receive 1 frame of the length specified in the title together with pre fit mounting parts.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-322",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Airbrush Holder Frame 250mm (VAX-ABHF-250)",
    "sku": "VAX-ABHF-250-1",
    "priceEur": 8.41,
    "priceGbp": 7.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-ABH-6-Airbrush-Holder-Assembly-Render-Reworked.png",
    "description": "https://youtu.be/SIJMAgx7J6c\nMount them vertically or horizontally to our Frame tm available in different lengths dependent upon how many airbrushes you want to hold. Comes with a pre screwed bolted and rubberised mount for easy fix. Illustration shows a fully loaded version.\nPlease note that you will receive 1 frame of the length specified in the title together with pre fit mounting parts.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-321",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Airbrush Holder Frame 200mm (VAX-ABHF-200)",
    "sku": "VAX-ABHF-200",
    "priceEur": 7.01,
    "priceGbp": 5.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-ABH-6-Airbrush-Holder-Assembly-Render-Reworked.png",
    "description": "https://youtu.be/SIJMAgx7J6c\nMount them vertically or horizontally to our Frame tm available in different lengths dependent upon how many airbrushes you want to hold. Comes with a pre screwed bolted and rubberised mount for easy fix. Illustration shows a fully loaded version.\nPlease note that you will receive 1 frame of the length specified in the title together with pre fit mounting parts.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-319",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir Airbrush Holder Frame 150mm (VAX-ABHF-150)",
    "sku": "VAX-ABHF-150",
    "priceEur": 5.6,
    "priceGbp": 4.79,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-ABH-6-Airbrush-Holder-Assembly-Render-Reworked.png",
    "description": "https://youtu.be/SIJMAgx7J6c\nMount them vertically or horizontally to our Frame tm available in different lengths dependent upon how many airbrushes you want to hold. Comes with a pre screwed bolted and rubberised mount for easy fix. Illustration shows a fully loaded version.\nPlease note that you will receive 1 frame of the length specified in the title together with pre fit mounting parts.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-317",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir tm Needle Cap Tray (VAX-NCH4)",
    "sku": "VA-317",
    "priceEur": 11.22,
    "priceGbp": 9.59,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-ACH4-Aircap-Holder-4-Render-Reworked.png",
    "description": "Holds up to 4 needle caps it screws directly to our Vframe – ideal for our Airbrush Holder Vframes.\nImage shows additional airbrush holders and\nHolds up to 4 needle caps it screws directly to our Vframe – ideal for our Airbrush Holder Vframes.\nImage shows additional airbrush holders and VFrames.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-314",
    "brand": "VsionAir",
    "category": "Tool & Airbrush Holders",
    "name": "VsionAir tm Airbrush Holder (VAX-ABH)",
    "sku": "VAX-ABH",
    "priceEur": 8.41,
    "priceGbp": 7.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-ABH-Airbrush-Holder-Render-Reworked.png",
    "description": "https://youtu.be/SIJMAgx7J6c\nA simple little holder. That allows you to screw it directly to the VsionFrame TM and set the angle of the airbrush – suitable for all our Tool Bars, and our Independent Airbrush Stations.\nYou can expand the number of holders buy adding our VsionFrame TM",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-312",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir tm Skateboard Jig (VAX-JG-SKBD)",
    "sku": "VAX-JG-SKBD",
    "priceEur": 70.19,
    "priceGbp": 59.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-HG-SKBD-Skateboard-Jig-Assembly-Render-Reworked.png",
    "description": "We love boards! and what better way to pay homage to them than to have an actual skateboard jig.\n\nThis jig is ideal for all the prep work, priming sanding, base coating, flaking, painting, leafing, striping, clear coating, and polishing. You can set the angle lock it into place and do what you want.\nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.\nTo download a copy of the Assembly Drawing please click this link\nTo download a copy of the packing list please click this link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-310",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir Thermal Mug Jig (VAX-JG-TM)",
    "sku": "VAX-JG-TM",
    "priceEur": 70.19,
    "priceGbp": 59.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-TM-Thermal-Mug-Jig-Reworked.png",
    "description": "We’ve heard that our American brothers and sisters custom paint a lot of thermal mugs such as YETI’s TM and the like. We’re such affable people “us Brits” that we wanted to make it easier for you to paint them. It relies on rubber discs that slide into the cup and hold it with suction.\nThey’re set on a threaded rod so you can set the height they sit within the cup. The rod is connected to our VsionAir TM Frame and comes with a height adjuster so it simply drops into either the Desk Mount Stand or the TriStand TM\nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-308",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir Motorcycle & Car Wheel Jig (VAX-Jg-WHL)",
    "sku": "VAX-Jg-WHL",
    "priceEur": 56.15,
    "priceGbp": 47.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-WHL-Wheel-Jig-Render1-Reworked.png",
    "description": "A very simple little jig that enables you to place a wheel on it and turn it, ideal for spraying or pinstriping. It has a removable top spinner for car wheels and a shaft for motorcycle wheels.\nThat’s it – simple but really useful !\nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-306",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir Motorcycle Helmet Jig (VAX-JG-HLMT)",
    "sku": "VAX-JG-HLMT",
    "priceEur": 129.16,
    "priceGbp": 110.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-HLMT-Render-1-Reworked.png",
    "description": "A very innovative design that utilises a unique chinstrap bracket and heavy duty rubber to hold the helmet to our internal VsionFrameTM, that is connected to another unique rotational ball and clamp mechanism. Giving you the ability to move and lock the helmet in the same way you can move your head.\nAgain it has the height adjuster bracket that fits into our Angle Lock giving you a stable base and the ability to do any type of work on it. \nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.\nDownload the Assembly Drawing by clicking this link\nDownload the Parts & Assemblies Packing List by clicking this link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-304",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir Motorcycle Tank Rotisserie Jig (VAX-JG-MCTNK)",
    "sku": "VAX-JG-MCTNK",
    "priceEur": 266.75,
    "priceGbp": 227.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-MCTNK_VsionAir_Motorcycle_Tank_Jig_reworked.png",
    "description": "A really cool and useful jig. This jig comes with varying lengths of VsionFrame and different mount options, basically it can handle any tank that has mount points even the “bung” type. The jig enables you to not only spin the tank on its horizontal frame axis but also the vertical axis, allowing you to spray the entire tank whilst being stood on one spot. You can lock the tank at any angle so you can use it for prep work, masking, pin striping, airbrushing and even polishing.\nThis jig will evolve as more tank dimensional information comes to light, any potential items will be made available discounted for existing customers upon proof of original purchase. So keep your receipts!\nIn the kit is a range of sizes of VFrame and various brackets, threaded bars nuts, bolts and threaded bung inserts and a height adjuster. there are also 2 angle lock adjuster brackets to lock the horizontal motion everything when working.\nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-302",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "Vsionair Motorcycle Fender/Mudguard Jig Set (VAX-JG-MCFDR)",
    "sku": "VAX-JG-MCFDR",
    "priceEur": 112.31,
    "priceGbp": 95.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-MCFDR-Render1-Reworked.png",
    "description": "No more balancing fenders on water filled gallon tins. Held securely by unique screw in fixings that secure the fender.\nUsing our VsionAir TM Height Bracket you can spin the fender on the vertical axis – again allowing you to paint the whole fender whilst stood in one position. You can also lock the jig – so you can use it for prep work, masking, pin striping, airbrushing and even polishing.\nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.\nDownload the Assembly Drawing by clicking this link\nDownload the Parts & Assemblies Packing List by clicking this link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-297",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir Electric Guitar Jig (VAX-JG-GTR)",
    "sku": "VAX-JG-GTR",
    "priceEur": 196.55,
    "priceGbp": 167.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-GTR-Guitar-Body-Jig-A-Render.png",
    "description": "VsionAir Electric Guitar Jig.\nComes with everything you need to hold both the neck and the body of the guitar. Both jigs have the height adjuster for the VsionFrame TM  enabling you to rotate the “neck” axis and also lock it into a specific angle, allowing you to spray the entire piece whilst being stood on one spot. Because you can also lock it at any angle, you can use it for prep work, masking, pin striping, airbrushing and even polishing. You can also change the angle enabling you work on the top/bottom straight on – no bending\nThis jig comes with 1 base mount that sits in the stands (desk & Tri-Stand) with an angle lock adjuster and 2 mount assemblies one for the body and one for the neck.\nAll our jigs can be used on both the Tri-Stand and Desk Mount Stand, meaning you can do the “dirty” work in the booth and then just lift them out and take to your studio to apply your artwork and detail. When you’ve finished take them back to the booth and clear coat, cut and polish all on one stand.\nTo download a copy of the Assembly Drawing please click this link\nTo download a copy of the packing list please click this link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-296",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "VsionAir TM A3 Airbrush Station Jig (VAX-JG-IABS-A3)",
    "sku": "VAX-JG-IABS-A3",
    "priceEur": 140.39,
    "priceGbp": 119.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-A3VSBD-A3-VsionBoard-Jig_Reworked.png",
    "description": "The ideal jig if you want to paint on canvass, specialist cards and papers, the Vsionair tm Independent Airbrush Station is able to hold up to A3 (ANSI B) in both landscape and portrait. It’s steel faced making it fantastic to use magnets to hold your stencils and work on.\nThe main structure is made from our unique VFrame tm which means that you can bolt any of our accessories to it.\nThe main VsionBoard tm is finished in a neutral matt cream powder coat.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-294",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "VsionAir TM A4 Airbrush Station Jig (VAX-JG-IABS-A4)",
    "sku": "VAX-JG-IABS-A4",
    "priceEur": 112.31,
    "priceGbp": 95.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-JG-A3VSBD-A3-VsionBoard-Jig_Reworked.png",
    "description": "The ideal jig if you want to paint on canvass, specialist cards and papers, the Vsionair tm Independent Airbrush Station is able to hold up to A4 (ANSI A) in both landscape or portrait. It’s steel faced making it fantastic to use magnets to hold your stencils and work on.\nThe main structure is made from our unique VFrame tm which means that you can bolt any of our accessories to it.\nThe main VsionBoard tm is finished in a neutral matt cream powder coat.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-293",
    "brand": "VsionAir",
    "category": "Work-Holding Jigs",
    "name": "VsionAir tm Canvass Jig 1500mm Spine (VAX-JG-CNVSS-1500)",
    "sku": "VAX-JG-CNVSS-1500",
    "priceEur": 168.47,
    "priceGbp": 143.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-CNVSS-Canvass-Jig-Reworked.png",
    "description": "Our Canvass jigs are ideal for holding canvasses up to 1300mm high. The top & bottom VFrame acts as a toolbar mount as well.\nWe can special build Easels using our Canvass Jigs and Tri-Stands to create Easels that will hold a canvass of up to 2.5mm high by what ever width you require.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-288",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VsionAir tm 60 LED Light with Mounting Brackets 600mm (VAX-LED-60)",
    "sku": "VAX-LED-60",
    "priceEur": 89.84,
    "priceGbp": 76.79,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/LEDLight.jpg",
    "description": "VsionAir tm 600mmLED Overhead Light, creates a nice bright workspace. works on 110 & 240 volt.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-284",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VAX Lighting, Camera & Dual Vertical Tool Bar Rig 1.2m (VAX-LCT-RIG-1200)",
    "sku": "VAX-LCT-RIG-1200",
    "priceEur": 154.43,
    "priceGbp": 131.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/1000mm_x_1200mm_Vertical_Tool_Bars__Lighting_Camera_Rig_Reworked.png",
    "description": "The VsioAir Lighting, Camera & Vertical Tool Bar Rig, is designed to provide you with the physical structure to mount lighting, cameras and any of our accessories directly to it. It bolts to the horizontal tool bar and with the use of the IABS Brackets enables you to angle the vertical bars from directly above to 90 degrees behind the work area. This is a real game changer to your work area – you’ll be amazed at what you can mount to this.\nIt mounts to both our Desk Mount Stand and our Tripod Stand (via our VsionAir Tool Bar). Available in 3 Widths 1m, 1.2m & 1.5m\nTo download the assembly instructions please click on link\nTo download the packing list please click on link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-282",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VAX Lighting, Camera & Dual Vertical Tool Bar Rig 1m (VAX-LCT-RIG-1000)",
    "sku": "VAX-LCT-RIG-1000",
    "priceEur": 140.39,
    "priceGbp": 119.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/1000mm_x_1200mm_Vertical_Tool_Bars__Lighting_Camera_Rig_Reworked.png",
    "description": "The VsioAir Lighting, Camera & Vertical Tool Bar Rig, is designed to provide you with the physical structure to mount lighting, cameras and any of our accessories directly to it. It bolts to the horizontal tool bar and with the use of the IABS Brackets enables you to angle the vertical bars from directly above to 90 degrees behind the work area. This is a real game changer to your work area – you’ll be amazed at what you can mount to this.\nIt mounts to both our Desk Mount Stand and our Tripod Stand (via our VsionAir Tool Bar). Available in 3 Widths 1m, 1.2m & 1.5m\nTo download the assembly instructions please click on link\nTp download the packing list please click on link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-281",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VsionFrame tm Tool Bar 1500mm (VAX-FRM-1500-TB)",
    "sku": "VAX-FRM-1500-TB",
    "priceEur": 36.49,
    "priceGbp": 31.19,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VsionFrame-Render-Reworked.png",
    "description": "If you want to expand the range of useful accessories to your workstation then look no further than our VsionFrame tm Tool Bar will bolt directly to both our Desk Mount Stand and our Tri-Stand, it will also bolt to the front our our Independent Airbrush Station if you also purchase and additional 2 of our VBrackets.\nThe VsionFrame Tool Bar is available in 5 sizes…\n500mm, 750mm, 1000mm, 1200mm & 1500mm.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-280",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VsionFrame tm Tool Bar 1200mm (VAX-FRM-1200-TB)",
    "sku": "VAX-FRM-1200-TB",
    "priceEur": 33.68,
    "priceGbp": 28.79,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VsionFrame-Render-Reworked.png",
    "description": "If you want to expand the range of useful accessories to your workstation then look no further than our VsionFrame tm Tool Bar will bolt directly to both our Desk Mount Stand and our Tri-Stand, it will also bolt to the front our our Independent Airbrush Station if you also purchase and additional 2 of our VBrackets.\nThe VsionFrame Tool Bar is available in 5 sizes…\n500mm, 750mm, 1000mm, 1200mm & 1500mm.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-279",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VsionFrame tm Tool Bar 1000mm (VAX-FRM-1000-TB)",
    "sku": "VAX-FRM-1000-TB",
    "priceEur": 28.07,
    "priceGbp": 23.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VsionFrame-Render-Reworked.png",
    "description": "If you want to expand the range of useful accessories to your workstation then look no further than our VsionFrame tm Tool Bar will bolt directly to both our Desk Mount Stand and our Tri-Stand, it will also bolt to the front our our Independent Airbrush Station if you also purchase and additional 2 of our VBrackets.\nThe VsionFrame Tool Bar is available in 5 sizes…\n500mm, 750mm, 1000mm, 1200mm & 1500mm.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-278",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VsionFrame tm Tool Bar 750mm (VAX-FRM-750-TB)",
    "sku": "VAX-FRM-750-TB",
    "priceEur": 19.64,
    "priceGbp": 16.79,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VsionFrame-Render-Reworked.png",
    "description": "If you want to expand the range of useful accessories to your workstation then look no further than our VsionFrame tm Tool Bar will bolt directly to both our Desk Mount Stand and our Tri-Stand, it will also bolt to the front our our Independent Airbrush Station if you also purchase and additional 2 of our VBrackets.\nThe VsionFrame Tool Bar is available in 5 sizes…\n500mm, 750mm, 1000mm, 1200mm & 1500mm.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-270",
    "brand": "VsionAir",
    "category": "Tool Bars & Lighting Rigs",
    "name": "VsionFrame tm Tool Bar 500mm (VAX-FRM-500-TB)",
    "sku": "VAX-FRM-500-TB",
    "priceEur": 14.03,
    "priceGbp": 11.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VsionFrame-Render-Reworked.png",
    "description": "If you want to expand the range of useful accessories to your workstation then look no further than our VsionFrame tm Tool Bar will bolt directly to both our Desk Mount Stand and our Tri-Stand, it will also bolt to the front our our Independent Airbrush Station if you also purchase and additional 2 of our VBrackets.\nThe VsionFrame Tool Bar is available in 5 sizes…\n500mm, 750mm, 1000mm, 1200mm & 1500mm.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-268",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "VAX-IABS VsionAir Independent Airbrush Station",
    "sku": "VAX-IABS",
    "priceEur": 140.39,
    "priceGbp": 119.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-A3-IABS_VisonAir_Independent_Airbrush_Station_FKLogo.png",
    "description": "If you only paint on canvass, specialist cards and papers, the Vsionair tm Independent Airbrush Station forms the ideal base. It is able to hold up to A3 (ANSI B) in both landscape and portrait. It’s steel faced making it fantastic to use magnets to hold your stencils and work on.\nThe main structure is made from our unique VFrame tm which means that you can bolt any of our accessories to it. I has stops on the front base to stop it from being pushed away when pressure is applied.\nYou can also purchase additional tool bars that will fasten to the front base enabling you to expand the range off accessories you can add.\nIf you later wish to move to our Desk Mount and or Tri-Stand, we have an upgrade kit which will allow you to convert it, giving you flexibility and peace of mind.\nThe main VsionBoard is now finished in a neutral matt mid grey powder coat. This colour was recommended by Marissa Oosterlee being this colour maintains your eyes colour balance for extreme accuracy of colour matching whilst painting.\nTo download a copy of the Assembly Drawing please click this link\nTo download a copy of the packing list please click this link",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-265",
    "brand": "VsionAir",
    "category": "Fixings, Knobs & Hardware",
    "name": "Angle Lock Adjuster (VAX-ALA)",
    "sku": "VAX-ALA",
    "priceEur": 36.26,
    "priceGbp": 30.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/06/VAX-ALA-Angle-Lock-Adjuster-Render-Web.png",
    "description": "Our VsionAir Angle & Lock Adjuster is an optional accessory for both our Desk Mount & TriStand it bolts directly to the top bracket.\nIt allows you to drop the jig in it and spin it on the vertical axis freely, but also has the ability to lock the jig at any rotational angle. Making it ideal for locking your parts when performing critical actions, for example welding. taping up – lining out, striping, airbrushing, polishing.\nFinished in bright zinc.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-262",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "Crown Feet for VsionAir Tri-Stand (VAX-CRWN-FT)",
    "sku": "VAX-CRWN-FT",
    "priceEur": 23.86,
    "priceGbp": 20.39,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-CRWN-FT.png",
    "description": "The Crown Feet, are not just a really cool aesthetic to enhance the Tri-Stand.\nThey are also a functional addition in that if you have a down draft gridded floor they stop the legs from potentially falling into the gridded openings and falling over. Finished in red powder coat and supplied with mounting bolts, nuts and washers.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-260",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "VsionAir Desk Mount Clamp (VAX-DM2)",
    "sku": "VAX-DM2",
    "priceEur": 42.11,
    "priceGbp": 35.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/Desk_Mount_Clamp_Assembly_Reworked.png",
    "description": "Vsionair VAX-DM2 Desk Mount Clamp is made from 4mm steel, it simply slides up Desk Mount down tube and then tightens with two 8mm threaded handles.\nProviding a great unobtrusive mount.\nWe have to say if you’re going to holding really heavy items – we strongly recommend using the drill and screw method supplied with your desk mount.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-256",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "VsionAir Desk Mount -(VAX-DM1)",
    "sku": "VAX-DM1",
    "priceEur": 112.31,
    "priceGbp": 95.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-DM1-Desk-Mount-Assembly.png",
    "description": "Being made from 6mm thick aluminium plate, it is very strong. The beauty of our platform system is the flexibility you have holding your work piece by simply dropping the jig into the tubed hole and you’re ready to go. You can add all your tools and accessories by bolting the horizontal tool bar to the base.  It can be mounted using two methods. Method 1. Drilling holes in the desk top will allow you slide the Desk Mount in and out to accommodate challenging items like fenders (mudguards) or if you don’t want to drill your desk top, you can purchase the Desk Mount Clamp (Method 2) pictured. Finished in our signature red & black powder coat.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  },
  {
    "id": "va-255",
    "brand": "VsionAir",
    "category": "Base Stands & Easels",
    "name": "VsionAir Tri-Stand (VAX-TRI)",
    "sku": "VAX-TRI",
    "priceEur": 280.79,
    "priceGbp": 239.99,
    "inStock": true,
    "isPreOrder": false,
    "badge": "VSIONAIR RIG",
    "image": "https://vsionair.com/wp-content/uploads/2021/05/VAX-TRI-Vsion-Air-TriPod-with-Feet.png",
    "description": "Our TristandTM is made of aluminium, making it very strong and portable. The brackets are designed to be extremely adjustable, having both fixed holes for speed and slots for maximum adjustability.\n The square bracket on the top enables you to bolt additional horizontal toolbars to mount your desired accessories. You can add the Angle Lock, this will allow you to lock your jigs on the vertical axis. \nImage shows the optional feet. They are not typically needed unless you have a slotted steel floor such as in down draught booths. Finished in red & black powder coat.",
    "sizes": [
      "Standard Rig"
    ],
    "packSizes": [
      "Single Unit"
    ],
    "hasOptions": false,
    "hideFromStorefront": true,
    "repricingHold": true
  }
];
