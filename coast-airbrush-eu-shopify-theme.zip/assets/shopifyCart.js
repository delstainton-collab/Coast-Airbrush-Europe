// Shopify & E-Commerce Integration Layer for Coast Airbrush Europe

import { recommendContainerPack } from './mixingEngine.js';

export class ShopifyCartManager {
  constructor(shopifyDomain = "shop.coastairbrush.eu") {
    this.shopifyDomain = shopifyDomain;
    this.cartItems = JSON.parse(localStorage.getItem('coast_cart_items') || '[]');
    this.listeners = [];
  }

  onCartUpdate(callback) {
    this.listeners.push(callback);
  }

  notifyListeners() {
    localStorage.setItem('coast_cart_items', JSON.stringify(this.cartItems));
    this.listeners.forEach(cb => cb(this.getCartSummary()));
  }

  /**
   * Simulates Shopify POST /cart/add.js
   */
  addItem(item) {
    const existingIndex = this.cartItems.findIndex(i => i.sku === item.sku);
    if (existingIndex > -1) {
      this.cartItems[existingIndex].quantity += (item.quantity || 1);
    } else {
      this.cartItems.push({
        id: item.id || `var_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        sku: item.sku,
        name: item.name,
        containerLabel: item.containerLabel || 'Quart',
        quantity: item.quantity || 1,
        unitPriceUSD: item.unitPriceUSD || 49.99,
        subtotalUSD: (item.unitPriceUSD || 49.99) * (item.quantity || 1),
        properties: item.properties || {}
      });
    }
    this.notifyListeners();
  }

  /**
   * Adds entire mixed recipe BOM into Shopify Cart Drawer
   */
  addRecipeToShopifyCart(recipe, projectName = "Custom Color Mix") {
    if (!recipe || !recipe.components) return;

    recipe.components.forEach(comp => {
      const selected = comp.selectedProduct;
      const sku = selected ? selected.sku : comp.sku;
      const name = selected ? selected.name : comp.name;
      const basePrice = selected ? selected.priceUSD : 49.99;

      const packItems = recommendContainerPack(sku, name, comp.volumeMl, basePrice);
      packItems.forEach(item => {
        this.addItem({
          ...item,
          properties: {
            "Mixed Formula": recipe.systemName,
            "Target Scale Weight": `${comp.cumulativeWeightGrams}g`,
            "Volume Needed": `${comp.volumeMl}mL`
          }
        });
      });
    });
  }

  removeItem(sku) {
    this.cartItems = this.cartItems.filter(i => i.sku !== sku);
    this.notifyListeners();
  }

  clearCart() {
    this.cartItems = [];
    this.notifyListeners();
  }

  getCartSummary() {
    const totalCount = this.cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalPriceUSD = this.cartItems.reduce((sum, item) => sum + (item.unitPriceUSD * item.quantity), 0);
    return {
      items: this.cartItems,
      totalCount,
      totalPriceUSD: Math.round(totalPriceUSD * 100) / 100
    };
  }

  /**
   * Generates a 1-click Shopify Cart Permalink URL for live checkout.
   */
  generateShopifyCartPermalink() {
    if (this.cartItems.length === 0) return "";
    const itemsParam = this.cartItems.map(item => `${item.sku}:${item.quantity}`).join(',');
    return `https://${this.shopifyDomain}/cart/${itemsParam}?note=${encodeURIComponent("Coast Airbrush EU Store Add-On Order")}`;
  }

  exportToCSV() {
    if (this.cartItems.length === 0) return;
    let csvContent = "data:text/csv;charset=utf-8,SKU,Product Name,Container Size,Quantity,Unit Price (USD),Subtotal (USD)\n";
    this.cartItems.forEach(item => {
      csvContent += `"${item.sku}","${item.name}","${item.containerLabel}",${item.quantity},${item.unitPriceUSD},${(item.unitPriceUSD * item.quantity).toFixed(2)}\n`;
    });
    const summary = this.getCartSummary();
    csvContent += `,,,TOTAL,,${summary.totalPriceUSD.toFixed(2)}\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `coast_airbrush_shopify_cart_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  exportToJSON(recipe) {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ recipe, cart: this.getCartSummary() }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `coast_airbrush_order_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }
}
