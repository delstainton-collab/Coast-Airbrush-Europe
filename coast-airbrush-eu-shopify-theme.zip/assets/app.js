// Coast Airbrush Europe - Main Application Controller
import { HOK_SHIMRIN2_CATALOG } from '../data/hok_shimrin2.js';
import { ACE_OF_SHADES_CATALOG } from '../data/ace_of_shades.js';
import { ECOM_CATALOG } from '../data/full_ecom_catalog.js';
import { calculateRequiredVolume, calculateMixingRecipe, PRESET_PANELS, CONVERSIONS } from './mixingEngine.js';
import { ShopifyCartManager } from './shopifyCart.js';

class PaintSystemApp {
  constructor() {
    this.currentCatalog = HOK_SHIMRIN2_CATALOG;
    this.selectedSystem = this.currentCatalog.mixingSystems[0];
    this.selectedColors = {};
    this.totalMlNeeded = 500;
    this.currentRecipe = null;
    this.shopifyCartManager = new ShopifyCartManager();
    this.activeBrandFilter = 'all';
    this.searchQuery = '';

    this.initUI();
  }

  addSafeListener(id, event, callback) {
    const el = document.getElementById(id);
    if (el) el.addEventListener(event, callback);
  }

  initUI() {
    // Navigation Tabs
    this.setupTabs();

    // Event Listeners for inputs
    this.addSafeListener('select-mixing-system', 'change', (e) => this.onSystemChange(e.target.value));
    this.addSafeListener('input-total-volume', 'input', () => this.updateCalculation());
    this.addSafeListener('select-volume-unit', 'change', () => this.updateCalculation());

    // Shop Filters & Search
    this.setupShopFilters();

    // Surface area presets
    this.setupCoverageCalculator();

    // Cart Drawer & Hero Banner actions
    this.setupShopifyDrawer();

    // Export buttons
    this.addSafeListener('btn-export-shopify-permalink', 'click', () => this.checkoutShopify());
    this.addSafeListener('btn-export-csv-bom', 'click', () => this.exportCSV());
    this.addSafeListener('btn-export-json-recipe', 'click', () => this.exportJSON());
    
    this.addSafeListener('btn-add-to-cart', 'click', () => {
      this.shopifyCartManager.addRecipeToShopifyCart(this.currentRecipe);
      this.openCartDrawer();
    });

    this.addSafeListener('btn-send-to-scale', 'click', () => this.openScaleTab());
    this.addSafeListener('btn-open-mixing-addon', 'click', () => {
      const tabScale = document.getElementById('tab-scale');
      if (tabScale) tabScale.click();
    });

    // Listen for cart changes
    this.shopifyCartManager.onCartUpdate((summary) => this.renderCartSummary(summary));

    // Initial render
    this.renderSystemsDropdown();
    this.renderColorSwatches();
    this.renderStorefrontGrid();
    this.updateCalculation();
    this.renderCartSummary(this.shopifyCartManager.getCartSummary());
  }

  switchBrand(catalog, activeBtnId) {
    this.currentCatalog = catalog;
    this.selectedSystem = catalog.mixingSystems[0];
    this.selectedColors = {};

    document.querySelectorAll('.brand-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById(activeBtnId).classList.add('active');

    this.renderSystemsDropdown();
    this.renderColorSwatches();
    this.renderStorefrontGrid();
    this.updateCalculation();
  }

  setupTabs() {
    const tabs = [
      { id: 'tab-calculator', viewId: 'view-calculator' },
      { id: 'tab-scale', viewId: 'view-scale' },
      { id: 'tab-coverage', viewId: 'view-coverage' },
      { id: 'tab-storefront', viewId: 'view-storefront' }
    ];

    tabs.forEach(tab => {
      const btn = document.getElementById(tab.id);
      if (btn) {
        btn.addEventListener('click', () => {
          tabs.forEach(t => {
            const b = document.getElementById(t.id);
            const v = document.getElementById(t.viewId);
            if (b) b.classList.remove('active');
            if (v) v.style.display = 'none';
          });
          btn.classList.add('active');
          const targetView = document.getElementById(tab.viewId);
          if (targetView) targetView.style.display = 'block';
        });
      }
    });
  }

  setupShopifyDrawer() {
    const toggleBtn = document.getElementById('btn-toggle-cart-drawer');
    const closeBtn = document.getElementById('btn-close-cart-drawer');
    const overlay = document.getElementById('cart-drawer-overlay');

    if (toggleBtn) toggleBtn.addEventListener('click', () => this.openCartDrawer());
    if (closeBtn) closeBtn.addEventListener('click', () => this.closeCartDrawer());
    if (overlay) overlay.addEventListener('click', () => {
      this.closeCartDrawer();
      this.closeB2BModal();
    });

    this.addSafeListener('btn-drawer-checkout', 'click', () => this.checkoutShopify());
    this.setupB2BPortal();
  }

  setupB2BPortal() {
    this.addSafeListener('btn-b2b-login', 'click', () => this.openB2BModal());
    this.addSafeListener('btn-close-b2b-modal', 'click', () => this.closeB2BModal());
    this.addSafeListener('b2b-modal-overlay', 'click', () => this.closeB2BModal());

    const tabLogin = document.getElementById('b2b-tab-login');
    const tabApply = document.getElementById('b2b-tab-apply');
    const viewLogin = document.getElementById('b2b-view-login');
    const viewApply = document.getElementById('b2b-view-apply');

    if (tabLogin && tabApply) {
      tabLogin.addEventListener('click', () => {
        tabLogin.classList.add('active');
        tabApply.classList.remove('active');
        if (viewLogin) viewLogin.style.display = 'block';
        if (viewApply) viewApply.style.display = 'none';
      });

      tabApply.addEventListener('click', () => {
        tabApply.classList.add('active');
        tabLogin.classList.remove('active');
        if (viewApply) viewApply.style.display = 'block';
        if (viewLogin) viewLogin.style.display = 'none';
      });
    }

    this.addSafeListener('btn-submit-b2b-login', 'click', () => {
      const acc = document.getElementById('b2b-input-account').value || 'TRADE-DEALER-EU';
      this.isB2BMode = true;
      this.closeB2BModal();
      
      const btnLogin = document.getElementById('btn-b2b-login');
      if (btnLogin) {
        btnLogin.style.borderColor = 'var(--scale-led)';
        btnLogin.style.color = 'var(--scale-led)';
        btnLogin.innerHTML = `🟢 B2B Trade: ${acc} (30% Off)`;
      }

      this.renderStorefrontGrid();
      alert(`🎉 B2B Dealer Portal Unlocked for ${acc}!\n\nAll catalog prices now reflect 30% Wholesale Trade Discount. Orders will route via B2B Zero-Upfront Pack & Weigh workflow.`);
    });

    this.addSafeListener('btn-submit-b2b-apply', 'click', () => {
      alert("📤 Trade Credit Application Submitted!\nOur European sales concierge will verify your VAT ID and activate your wholesale account within 2 hours.");
      this.closeB2BModal();
    });
  }

  openB2BModal() {
    const overlay = document.getElementById('b2b-modal-overlay');
    const modal = document.getElementById('b2b-modal');
    if (overlay) overlay.classList.add('open');
    if (modal) {
      modal.style.opacity = '1';
      modal.style.pointerEvents = 'auto';
      modal.style.transform = 'translate(-50%, -50%) scale(1)';
    }
  }

  closeB2BModal() {
    const overlay = document.getElementById('b2b-modal-overlay');
    const modal = document.getElementById('b2b-modal');
    if (overlay) overlay.classList.remove('open');
    if (modal) {
      modal.style.opacity = '0';
      modal.style.pointerEvents = 'none';
      modal.style.transform = 'translate(-50%, -50%) scale(0.9)';
    }
  }

  openCartDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');
    if (overlay) overlay.classList.add('open');
    if (drawer) drawer.classList.add('open');
  }

  closeCartDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');
    if (overlay) overlay.classList.remove('open');
    if (drawer) drawer.classList.remove('open');
  }

  renderSystemsDropdown() {
    const select = document.getElementById('select-mixing-system');
    select.innerHTML = '';
    this.currentCatalog.mixingSystems.forEach(sys => {
      const opt = document.createElement('option');
      opt.value = sys.id;
      opt.textContent = sys.name;
      select.appendChild(opt);
    });
    select.value = this.selectedSystem.id;
    this.updateSystemDescription();
  }

  updateSystemDescription() {
    const desc = document.getElementById('system-description');
    desc.innerHTML = `<strong>${this.selectedSystem.name}</strong><br>${this.selectedSystem.description}<br><span style="color: var(--accent-cyan); font-weight:700;">Formula: ${this.selectedSystem.ratioText}</span>`;
  }

  onSystemChange(systemId) {
    this.selectedSystem = this.currentCatalog.mixingSystems.find(s => s.id === systemId) || this.currentCatalog.mixingSystems[0];
    this.updateSystemDescription();
    this.updateCalculation();
  }

  setupShopFilters() {
    const searchInput = document.getElementById('input-shop-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.toLowerCase().trim();
        this.renderStorefrontGrid();
      });
    }

    const brandSelect = document.getElementById('select-brand-filter');
    if (brandSelect) {
      brandSelect.addEventListener('change', (e) => {
        this.activeBrandFilter = e.target.value;
        this.renderStorefrontGrid();
      });
    }

    const categorySelect = document.getElementById('select-category-filter');
    if (categorySelect) {
      categorySelect.addEventListener('change', (e) => {
        this.activeCategoryFilter = e.target.value;
        this.renderStorefrontGrid();
      });
    }

    const subcatBtns = document.querySelectorAll('.flake-subcategory-bar .filter-btn');
    subcatBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        subcatBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.activeFlakeSubcat = btn.getAttribute('data-flake-subcat');
        this.renderStorefrontGrid();
      });
    });

    const resetBtn = document.getElementById('btn-reset-filters');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        this.activeBrandFilter = 'all';
        this.activeCategoryFilter = 'all';
        this.activeFlakeSubcat = 'all';
        this.searchQuery = '';
        if (brandSelect) brandSelect.value = 'all';
        if (categorySelect) categorySelect.value = 'all';
        if (searchInput) searchInput.value = '';
        subcatBtns.forEach(b => b.classList.remove('active'));
        if (subcatBtns[0]) subcatBtns[0].classList.add('active');
        this.renderStorefrontGrid();
      });
    }
  }

  renderColorSwatches() {
    const container = document.getElementById('swatch-container');
    container.innerHTML = '';

    this.currentCatalog.products.forEach(prod => {
      const card = document.createElement('div');
      card.className = 'swatch-card';
      card.innerHTML = `
        <div class="swatch-preview" style="background-color: ${prod.hex || '#64748b'};"></div>
        <div class="swatch-info">
          <div class="swatch-name">${prod.name}</div>
          <div class="swatch-sku">${prod.sku}</div>
        </div>
      `;
      card.addEventListener('click', () => {
        document.querySelectorAll('.swatch-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        this.selectedColors['base'] = prod;
        this.updateCalculation();
      });
      container.appendChild(card);
    });
  }

  renderStorefrontGrid() {
    const container = document.getElementById('store-products-grid');
    if (!container) return;
    container.innerHTML = '';

    let filtered = ECOM_CATALOG;

    if (this.activeBrandFilter && this.activeBrandFilter !== 'all') {
      filtered = filtered.filter(p => p.brand.toLowerCase() === this.activeBrandFilter.toLowerCase());
    }

    if (this.activeCategoryFilter && this.activeCategoryFilter !== 'all') {
      filtered = filtered.filter(p => {
        if (Array.isArray(p.category)) {
          return p.category.some(c => c.toLowerCase() === this.activeCategoryFilter.toLowerCase());
        }
        return p.category.toLowerCase() === this.activeCategoryFilter.toLowerCase();
      });
    }

    if (this.activeFlakeSubcat && this.activeFlakeSubcat !== 'all') {
      filtered = filtered.filter(p => {
        const ft = (p.flakeType || '').toLowerCase();
        const nm = p.name.toLowerCase();
        const target = this.activeFlakeSubcat.toLowerCase();
        return ft.includes(target) || nm.includes(target);
      });
    }

    if (this.searchQuery) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(this.searchQuery) ||
        p.sku.toLowerCase().includes(this.searchQuery) ||
        (Array.isArray(p.category) ? p.category.join(' ').toLowerCase().includes(this.searchQuery) : p.category.toLowerCase().includes(this.searchQuery)) ||
        p.description.toLowerCase().includes(this.searchQuery)
      );
    }

    // Update Counter Text
    const counterEl = document.getElementById('shop-results-count');
    if (counterEl) {
      const brandText = this.activeBrandFilter === 'all' ? 'All Brands' : this.activeBrandFilter;
      const catText = this.activeCategoryFilter === 'all' ? 'All Categories' : this.activeCategoryFilter;
      counterEl.textContent = `Showing ${filtered.length} of ${ECOM_CATALOG.length} products (${brandText} › ${catText})`;
    }

    if (filtered.length === 0) {
      container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted); font-size: 14px;">No products found matching your current filter selections. Click "Reset All Filters" above to see all items.</div>`;
      return;
    }

    filtered.forEach(prod => {
      const card = document.createElement('div');
      card.className = 'product-card metal-sheen';
      card.style.cssText = 'background: var(--bg-card); border-radius: 8px; padding: 16px; border: 1px solid var(--border-color); display: flex; flex-direction: column; justify-content: space-between; position: relative; overflow: hidden;';

      const isPaint = prod.category === 'Solvent Paints';
      
      const priceMultiplier = this.isB2BMode ? 0.70 : 1.0;
      const displayPriceEur = prod.priceEur * priceMultiplier;
      const displayPriceGbp = prod.priceGbp * priceMultiplier;

      const badgeText = this.isB2BMode ? '🏢 30% B2B TRADE' : prod.badge;
      const buyText = this.isB2BMode 
        ? '📦 Add to B2B Order (Pack & Weigh)' 
        : (prod.isPreOrder ? '⚡ Pre-Order (100% Upfront)' : '🛒 Add to Cart');
      
      const isTape = prod.hasTapeOptions || prod.category === 'Masking Products' || prod.name.includes('Tape');
      const sizeLabel = isTape ? 'Tape Width / Roll Size' : 'Flake / Product Size';
      
      const hasSizes = prod.sizes && prod.sizes.length > 0;
      const hasPacks = prod.packSizes && prod.packSizes.length > 0;

      let variantControls = '';
      if (hasSizes || hasPacks) {
        variantControls += '<div style="display: flex; gap: 8px; margin-bottom: 12px; flex-wrap: wrap;">';
        if (hasSizes) {
          variantControls += `
            <div style="flex: 1; min-width: 120px;">
              <label style="font-size: 10px; font-weight: 700; color: var(--accent-cyan); text-transform: uppercase; display: block; margin-bottom: 2px;">${sizeLabel}</label>
              <select class="form-control select-flake-size" style="font-size: 11px; padding: 4px 6px; background: rgba(15,23,42,0.8);">
                ${prod.sizes.map(s => `<option value="${s}">${s}</option>`).join('')}
              </select>
            </div>
          `;
        }
        if (hasPacks) {
          variantControls += `
            <div style="flex: 1; min-width: 120px;">
              <label style="font-size: 10px; font-weight: 700; color: var(--primary-red); text-transform: uppercase; display: block; margin-bottom: 2px;">Pack / Box Size</label>
              <select class="form-control select-pack-size" style="font-size: 11px; padding: 4px 6px; background: rgba(15,23,42,0.8);">
                ${prod.packSizes.map(p => `<option value="${p}">${p}</option>`).join('')}
              </select>
            </div>
          `;
        }
        variantControls += '</div>';
      }

      const strikePriceHtml = this.isB2BMode ? `
        <span style="font-size: 13px; text-decoration: line-through; color: var(--text-muted); margin-right: 4px;">
          €${prod.priceEur.toFixed(2)}
        </span>
      ` : '';

      card.innerHTML = `
        <div>
          <div class="card-img-wrapper">
            <img src="${prod.image}" alt="${prod.name}">
            <span class="card-badge" style="${this.isB2BMode ? 'background: var(--scale-led); color: #000;' : ''}">${badgeText}</span>
          </div>
          <div style="font-size: 11px; font-weight: 700; color: var(--accent-cyan); text-transform: uppercase; margin-bottom: 4px; font-family: 'JetBrains Mono', monospace;">
            ${prod.brand} • ${prod.sku}
          </div>
          <div class="font-headline" style="font-size: 16px; font-weight: 800; line-height: 1.3; margin-bottom: 8px; color: var(--text-primary);">
            ${prod.name}
          </div>
          <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.4; margin-bottom: 12px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
            ${prod.description}
          </p>
        </div>

        <div>
          ${variantControls}

          <div style="display: flex; align-items: baseline; gap: 6px; margin-bottom: 12px; flex-wrap: wrap;">
            ${strikePriceHtml}
            <span class="card-price-eur" style="font-size: 20px; font-weight: 900; color: ${this.isB2BMode ? 'var(--scale-led)' : 'var(--text-primary)'}; font-family: 'Anybody', sans-serif;">
              €${displayPriceEur.toFixed(2)}
            </span>
            <span class="card-price-gbp" style="font-size: 12px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace;">
              (£${displayPriceGbp.toFixed(2)} GBP)
            </span>
          </div>

          <div style="display: flex; flex-direction: column; gap: 8px;">
            <button class="btn btn-primary btn-add-shop-cart" style="background: ${this.isB2BMode ? 'var(--scale-led)' : 'var(--primary-red)'}; color: ${this.isB2BMode ? '#000' : '#fff'}; font-weight: 800; font-size: 11px; border: 1px solid var(--accent-silver); text-transform: uppercase; padding: 10px; cursor: pointer;">
              ${buyText}
            </button>
            ${isPaint ? `
              <button class="btn btn-secondary btn-mix-paint" style="font-weight: 600; font-size: 11px; text-transform: uppercase; padding: 6px; border: 1px dashed var(--accent-cyan); color: var(--accent-cyan); cursor: pointer;">
                🎨 Custom Mixing Ratio Tool
              </button>
            ` : ''}
          </div>
        </div>
      `;

      // Handle Pack Size, Flake Size & Tape Width Price Matrix updates
      const sizeEl = card.querySelector('.select-flake-size');
      const packEl = card.querySelector('.select-pack-size');

      const updateCardPrice = () => {
        let currentPriceEur = prod.priceEur;
        let currentPriceGbp = prod.priceGbp;

        if (prod.fullMatrixPricing && sizeEl && packEl) {
          const match = prod.fullMatrixPricing.find(m => m.packSize === packEl.value && m.flakeSize === sizeEl.value);
          if (match) {
            currentPriceEur = match.priceEur;
            currentPriceGbp = match.priceGbp;
          }
        } else if (isTape && prod.tapePriceMatrix && sizeEl) {
          const match = prod.tapePriceMatrix.find(m => m.width === sizeEl.value);
          if (match) {
            currentPriceEur = match.priceEur;
            currentPriceGbp = match.priceGbp;
          }
        } else if (prod.packPriceMatrix && packEl) {
          const match = prod.packPriceMatrix.find(m => m.packSize === packEl.value);
          if (match) {
            currentPriceEur = match.priceEur;
            currentPriceGbp = match.priceGbp;
          }
        }

        const mult = this.isB2BMode ? 0.70 : 1.0;
        const finalEur = currentPriceEur * mult;
        const finalGbp = currentPriceGbp * mult;

        const eurEl = card.querySelector('.card-price-eur');
        const gbpEl = card.querySelector('.card-price-gbp');
        if (eurEl) eurEl.textContent = `€${finalEur.toFixed(2)}`;
        if (gbpEl) gbpEl.textContent = `(£${finalGbp.toFixed(2)} GBP)`;
      };

      if (sizeEl) sizeEl.addEventListener('change', updateCardPrice);
      if (packEl) packEl.addEventListener('change', updateCardPrice);

      card.querySelector('.btn-add-shop-cart').addEventListener('click', () => {
        let variantName = prod.name;
        let unitPrice = prod.priceEur;

        if (prod.fullMatrixPricing && sizeEl && packEl) {
          const match = prod.fullMatrixPricing.find(m => m.packSize === packEl.value && m.flakeSize === sizeEl.value);
          if (match) unitPrice = match.priceEur;
        } else if (isTape && prod.tapePriceMatrix && sizeEl) {
          const match = prod.tapePriceMatrix.find(m => m.width === sizeEl.value);
          if (match) unitPrice = match.priceEur;
        } else if (prod.packPriceMatrix && packEl) {
          const match = prod.packPriceMatrix.find(m => m.packSize === packEl.value);
          if (match) unitPrice = match.priceEur;
        }

        if (this.isB2BMode) unitPrice *= 0.70;

        const details = [];
        if (sizeEl) details.push(`Size: ${sizeEl.value}`);
        if (packEl) details.push(`Pack: ${packEl.value}`);
        if (details.length > 0) variantName += ` (${details.join(', ')})`;

        this.shopifyCartManager.addItem({
          sku: prod.sku,
          name: variantName,
          unitPriceUSD: unitPrice,
          quantity: 1
        });
        this.openCartDrawer();
      });

      if (isPaint) {
        card.querySelector('.btn-mix-paint').addEventListener('click', () => {
          document.getElementById('tab-calculator').click();
        });
      }

      container.appendChild(card);
    });
  }

  updateCalculation() {
    const rawVol = parseFloat(document.getElementById('input-total-volume').value) || 500;
    const unit = document.getElementById('select-volume-unit').value;

    let ml = rawVol;
    if (unit === 'floz') ml = rawVol * CONVERSIONS.FLOZ_TO_ML;
    if (unit === 'pt') ml = rawVol * CONVERSIONS.PT_TO_ML;
    if (unit === 'qt') ml = rawVol * CONVERSIONS.QT_TO_ML;

    this.totalMlNeeded = ml;

    const customComponents = [
      this.selectedColors['base'] || null,
      null, null
    ];

    this.currentRecipe = calculateMixingRecipe(this.selectedSystem, ml, customComponents);
    this.currentRecipe.brand = this.currentCatalog.brand;

    this.renderRecipeTable();
    this.renderScaleMode();
  }

  renderRecipeTable() {
    const tbody = document.getElementById('recipe-table-body');
    const badge = document.getElementById('formula-ratio-badge');
    tbody.innerHTML = '';

    if (!this.currentRecipe) return;

    badge.textContent = `Formula: ${this.currentRecipe.ratioText}`;

    this.currentRecipe.components.forEach(comp => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-weight: 700; color: var(--accent-cyan);">Step ${comp.stepIndex}</td>
        <td style="font-weight: 600;">${comp.name}</td>
        <td style="font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--text-muted);">${comp.sku}</td>
        <td style="font-weight: 700;">${comp.percentage}%</td>
        <td>${comp.volumeMl} mL <span style="color: var(--text-muted);">(${comp.volumeFlOz} fl oz)</span></td>
        <td>${comp.individualWeightGrams} g</td>
        <td><span class="cumulative-badge">${comp.cumulativeWeightGrams} g</span></td>
      `;
      tbody.appendChild(tr);
    });
  }

  renderScaleMode() {
    if (!this.currentRecipe) return;

    const container = document.getElementById('scale-steps-container');
    container.innerHTML = '';

    const firstStep = this.currentRecipe.components[0];
    document.getElementById('scale-active-step-title').textContent = `STEP 1: ADD ${firstStep.name.toUpperCase()}`;
    document.getElementById('scale-display-digits').textContent = `0.0 g`;
    document.getElementById('scale-target-digits').textContent = `${firstStep.cumulativeWeightGrams} g`;

    this.currentRecipe.components.forEach((comp, idx) => {
      const stepDiv = document.createElement('div');
      stepDiv.className = `step-card ${idx === 0 ? 'active' : ''}`;
      stepDiv.innerHTML = `
        <div>
          <strong style="color: var(--accent-cyan);">Step ${comp.stepIndex}: Add ${comp.name}</strong>
          <div style="font-size: 12px; color: var(--text-secondary);">Target Scale Weight: ${comp.cumulativeWeightGrams} g (Add +${comp.individualWeightGrams} g)</div>
        </div>
        <span class="cumulative-badge">${comp.cumulativeWeightGrams} g</span>
      `;
      container.appendChild(stepDiv);
    });
  }

  setupCoverageCalculator() {
    const presetSelect = document.getElementById('select-preset-panel');
    presetSelect.innerHTML = '';

    PRESET_PANELS.forEach(panel => {
      const opt = document.createElement('option');
      opt.value = panel.id;
      opt.textContent = panel.name;
      presetSelect.appendChild(opt);
    });

    presetSelect.addEventListener('change', (e) => {
      const selected = PRESET_PANELS.find(p => p.id === e.target.value);
      if (selected && selected.sqft > 0) {
        document.getElementById('input-custom-sqft').value = selected.sqft;
        this.updateCoverageEst();
      }
    });

    document.getElementById('input-custom-sqft').addEventListener('input', () => this.updateCoverageEst());
    document.getElementById('input-coats').addEventListener('input', () => this.updateCoverageEst());

    document.getElementById('btn-apply-calculated-volume').addEventListener('click', () => {
      const estMl = parseFloat(document.getElementById('est-vol-ml').textContent) || 500;
      document.getElementById('input-total-volume').value = Math.round(estMl);
      document.getElementById('select-volume-unit').value = 'ml';
      this.updateCalculation();

      // Switch back to recipe calculator tab
      document.getElementById('tab-calculator').click();
    });

    this.updateCoverageEst();
  }

  updateCoverageEst() {
    const sqft = parseFloat(document.getElementById('input-custom-sqft').value) || 0;
    const coats = parseInt(document.getElementById('input-coats').value) || 2;
    const vol = calculateRequiredVolume({ sqft, coats, coverageRateSqFtPerGal: this.currentCatalog.coverageRateSqFtPerGal });

    document.getElementById('est-vol-ml').textContent = vol.ml;
    document.getElementById('est-vol-floz').textContent = vol.floz;
    document.getElementById('est-vol-quarts').textContent = vol.quarts;
  }

  renderCartSummary(summary) {
    document.getElementById('header-cart-count').textContent = summary.totalCount;
    document.getElementById('bom-total-price').textContent = `$${summary.totalPriceUSD.toFixed(2)}`;
    document.getElementById('drawer-total-price').textContent = `$${summary.totalPriceUSD.toFixed(2)}`;

    // Render Sidebar BOM Container
    const bomContainer = document.getElementById('bom-items-container');
    bomContainer.innerHTML = '';

    if (summary.items.length === 0) {
      bomContainer.innerHTML = `<div style="font-size: 13px; color: var(--text-muted); text-align: center; padding: 16px;">Cart is empty. Calculate a mix or add products to get started.</div>`;
    } else {
      summary.items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'bom-item';
        div.innerHTML = `
          <div>
            <div style="font-weight: 700;">${item.name}</div>
            <div style="font-size: 11px; color: var(--text-muted);">SKU: ${item.sku} | Qty: ${item.quantity}</div>
          </div>
          <div style="font-weight: 700; color: var(--accent-cyan);">$${(item.unitPriceUSD * item.quantity).toFixed(2)}</div>
        `;
        bomContainer.appendChild(div);
      });
    }

    // Render Slide-Out Cart Drawer Items
    const drawerList = document.getElementById('drawer-items-list');
    drawerList.innerHTML = '';

    summary.items.forEach(item => {
      const card = document.createElement('div');
      card.style.cssText = 'background: rgba(30,41,59,0.6); padding: 12px; border-radius: 8px; border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;';
      card.innerHTML = `
        <div>
          <strong style="font-size: 13px;">${item.name}</strong>
          <div style="font-size: 11px; color: var(--text-muted);">SKU: ${item.sku} | Size: ${item.containerLabel}</div>
          <div style="font-size: 12px; color: var(--accent-cyan); font-weight: 700; margin-top: 4px;">$${item.unitPriceUSD.toFixed(2)} x ${item.quantity}</div>
        </div>
        <button class="btn-remove-item" style="background:transparent; border:none; color:var(--accent-red); cursor:pointer; font-size:18px;">&times;</button>
      `;
      card.querySelector('.btn-remove-item').addEventListener('click', () => {
        this.shopifyCartManager.removeItem(item.sku);
      });
      drawerList.appendChild(card);
    });
  }

  openScaleTab() {
    document.getElementById('tab-scale').click();
  }

  checkoutShopify() {
    const urlParams = new URLSearchParams(window.location.search);
    const liveOverride = urlParams.get('live') === 'true' || urlParams.get('review') === 'false';
    if (!liveOverride) {
      alert("⚠️ STAKEHOLDER REVIEW MODE: Online ordering is currently paused while Coast Airbrush USA conducts final operational & technical review. You can download the BOM recipe CSV/JSON to verify formula calculation.");
      return;
    }
    const url = this.shopifyCartManager.generateShopifyCartPermalink();
    if (url) {
      window.open(url, '_blank');
    } else {
      alert("Cart is empty! Calculate a paint mix or select products first.");
    }
  }

  exportCSV() {
    this.shopifyCartManager.exportToCSV();
  }

  exportJSON() {
    this.shopifyCartManager.exportToJSON(this.currentRecipe);
  }
}

// Initialize application on DOM content load
document.addEventListener('DOMContentLoaded', () => {
  window.app = new PaintSystemApp();
});
